import { GrammarRule, Suggestion, SystemLog } from './types';

// Initial rules list
export const INITIAL_RULES: GrammarRule[] = [
  {
    id: 'subject-verb-agreement',
    name: 'Subject-Verb Agreement',
    category: 'grammar',
    description: 'Checks if verbs agree with their subject pronouns (e.g., "they goes" -> "they go").',
    explanation: 'Singular subjects take singular verbs, and plural subjects take plural verbs.',
    enabled: true,
  },
  {
    id: 'articles',
    name: 'Incorrect Article ("a" vs "an")',
    category: 'grammar',
    description: 'Checks for correct use of articles before vowels or consonants (e.g., "a apple" -> "an apple").',
    explanation: 'Use "an" before words starting with a vowel sound, and "a" before consonant sounds.',
    enabled: true,
  },
  {
    id: 'capitalization',
    name: 'Proper Capitalization',
    category: 'grammar',
    description: 'Ensures proper nouns and the pronoun "I" are capitalized.',
    explanation: 'Proper nouns (like months, days of the week, languages) and the pronoun "I" should always be capitalized.',
    enabled: true,
  },
  {
    id: 'sentence-capitalization',
    name: 'Sentence Capitalization',
    category: 'punctuation',
    description: 'Ensures the first word of a sentence starts with a capital letter.',
    explanation: 'All complete sentences must begin with an uppercase letter.',
    enabled: true,
  },
  {
    id: 'duplicate-spaces',
    name: 'Duplicate Spaces',
    category: 'formatting',
    description: 'Detects multiple consecutive spaces.',
    explanation: 'Only a single space is required between words and punctuation marks.',
    enabled: true,
  },
  {
    id: 'repeated-words',
    name: 'Repeated Words',
    category: 'grammar',
    description: 'Identifies adjacent duplicated words (e.g., "the the").',
    explanation: 'Consecutive duplicate words are usually typing errors and should be removed.',
    enabled: true,
  },
  {
    id: 'basic-punctuation',
    name: 'Basic Punctuation Spacing',
    category: 'punctuation',
    description: 'Flags spaces before punctuation, or missing spaces after them (e.g., "hello , world" or "hello,world").',
    explanation: 'Punctuation marks like commas and periods should have no preceding space and must be followed by a space.',
    enabled: true,
  },
  {
    id: 'common-spelling',
    name: 'Spelling Correction',
    category: 'spelling',
    description: 'Identifies common misspelled words using an offline dictionary lookup.',
    explanation: 'Correct misspelled words using local spell dictionaries.',
    enabled: true,
  },
  {
    id: 'whitespace-cleanup',
    name: 'Trailing Whitespace',
    category: 'formatting',
    description: 'Finds extra spaces at the end of a line or sentence.',
    explanation: 'Trailing whitespaces are unnecessary and should be pruned.',
    enabled: false,
  },
];

// Offline spell-checking dictionary: common typos mapped to suggestions
const SPELL_DICTIONARY: { [key: string]: string } = {
  aple: 'apple',
  recieve: 'receive',
  recieved: 'received',
  definately: 'definitely',
  goverment: 'government',
  untill: 'until',
  seperate: 'separate',
  accomodate: 'accommodate',
  wierd: 'weird',
  tommorrow: 'tomorrow',
  tomorow: 'tomorrow',
  truely: 'truly',
  unforgiveable: 'unforgivable',
  publically: 'publicly',
  occured: 'occurred',
  arguement: 'argument',
  calender: 'calendar',
  basicly: 'basically',
  pharoah: 'pharaoh',
  maintainance: 'maintenance',
  lolipop: 'lollipop',
  bizzare: 'bizarre',
  coligue: 'colleague',
  colleague: 'colleague',
  knowlege: 'knowledge',
  enviroment: 'environment',
  suprise: 'surprise',
  comitment: 'commitment',
  embaras: 'embarrass',
  febuary: 'February',
  liason: 'liaison',
  millenium: 'millennium',
  necessery: 'necessary',
  nmae: 'name',
  teh: 'the',
  wrold: 'world',
  helol: 'hello',
  peolpe: 'people',
  speling: 'spelling',
  computr: 'computer',
  gramer: 'grammar',
  grammer: 'grammar',
  asistant: 'assistant',
  definetly: 'definitely',
  adress: 'address',
  adresses: 'addresses',
  // Casual/phonetic typos where generic edit-distance picks the wrong
  // same-distance word (e.g. "wat" is closer to "watt" than to "what").
  wat: 'what',
  gud: 'good',
  lik: 'like',
  ging: 'going',
  wether: 'weather',
  dis: 'this',
  dat: 'that',
  wen: 'when',
  wr: 'where',
  becuz: 'because',
  cuz: 'because',
  thx: 'thanks',
  pls: 'please',
  plz: 'please',
  ur: 'your',
};

// Vowel sound start indicators for a/an checks
const VOWELS = new Set(['a', 'e', 'i', 'o', 'u']);

// --- Real offline dictionary-based spell checking (Hunspell via nspell) ---
//
// Earlier versions of this file used a ~750-word hardcoded list with a
// homemade nearest-match search. That approach has a hard ceiling: real
// English has on the order of 170,000+ words (counting inflections), so a
// tiny static list will always miss common words ("school", "cute") and
// its naive edit-distance search has no way to prefer the *right* close
// match ("wat" -> "at" instead of "what").
//
// `dictionary-en` ships the actual open-source Hunspell English dictionary
// data as local files bundled into the app (no network request, ever), and
// `nspell` is a pure-JS Hunspell-compatible checker/suggester that reads it.
// This is the same class of dictionary used by LibreOffice/Firefox/Chrome's
// built-in spell checkers - a real dictionary instead of a short word list.
import nspell from 'nspell';

// Common English contractions - always treated as correctly spelled and
// checked before the dictionary lookup (nspell also recognizes these, but
// checking here first avoids an unnecessary async round trip).
const CONTRACTIONS = new Set([
  "don't", "doesn't", "didn't", "won't", "wouldn't", "can't", "couldn't",
  "shouldn't", "isn't", "aren't", "wasn't", "weren't", "hasn't", "haven't",
  "hadn't", "mustn't", "needn't", "shan't", "ain't",
  "i'm", "you're", "he's", "she's", "it's", "we're", "they're",
  "i've", "you've", "we've", "they've",
  "i'll", "you'll", "he'll", "she'll", "we'll", "they'll", "it'll",
  "i'd", "you'd", "he'd", "she'd", "we'd", "they'd",
  "let's", "that's", "there's", "here's", "who's", "what's", "where's",
  "how's", "when's", "why's",
]);

type NSpell = { correct: (w: string) => boolean; suggest: (w: string) => string[] };

let spellCheckerPromise: Promise<NSpell> | null = null;

// The .aff/.dic files are the real, open-source Hunspell English dictionary
// (the same one `dictionary-en` ships), copied into public/dictionaries/ so
// they can be fetched as plain static assets. This avoids importing
// `dictionary-en` directly in browser code, since that package's loader uses
// Node's `fs` module internally and does not work in a Vite/browser bundle.
// The files are served from the same origin as the app itself - no external
// network request, no telemetry, works fully offline once the app is loaded.
function getSpellChecker(): Promise<NSpell> {
  if (!spellCheckerPromise) {
    spellCheckerPromise = Promise.all([
      fetch('/dictionaries/en.aff').then((r) => r.text()),
      fetch('/dictionaries/en.dic').then((r) => r.text()),
    ]).then(([aff, dic]) => nspell({ aff, dic }) as unknown as NSpell);
  }
  return spellCheckerPromise;
}

// Check spelling against the curated fast-path table first (for very common
// casual typos where a phonetic-but-wrong Hunspell suggestion could otherwise
// win, e.g. "wat" is closer by edit-distance to "watt" than to "what"), then
// fall back to the full Hunspell dictionary for everything else.
const MAX_SPELLING_SUGGESTIONS = 5;

async function checkSpelling(
  word: string,
  customDict: string[],
  ignoredWords: string[]
): Promise<{ isMisspelled: boolean; suggestion?: string; alternatives?: string[] }> {
  if (CONTRACTIONS.has(word.toLowerCase())) {
    return { isMisspelled: false };
  }

  const cleanWord = word.toLowerCase().replace(/[^a-zA-Z']/g, '');
  if (!cleanWord || cleanWord.replace(/'/g, '').length <= 1) {
    return { isMisspelled: false };
  }

  const lowerIgnored = new Set(ignoredWords.map((w) => w.toLowerCase()));
  const lowerCustom = new Set(customDict.map((w) => w.toLowerCase()));
  if (lowerIgnored.has(cleanWord) || lowerCustom.has(cleanWord)) {
    return { isMisspelled: false };
  }

  const applyCasing = (replacement: string): string => {
    if (word[0] === word[0].toUpperCase() && word[0] !== word[0].toLowerCase()) {
      return replacement.charAt(0).toUpperCase() + replacement.slice(1);
    }
    return replacement;
  };

  // Fast path: curated high-confidence corrections for casual/phonetic typos.
  // These are unambiguous single-answer cases, so no alternatives list.
  if (SPELL_DICTIONARY[cleanWord]) {
    return { isMisspelled: true, suggestion: applyCasing(SPELL_DICTIONARY[cleanWord]) };
  }

  // Full dictionary check via Hunspell (nspell + dictionary-en).
  const spell = await getSpellChecker();
  if (spell.correct(cleanWord) || lowerCustom.has(cleanWord)) {
    return { isMisspelled: false };
  }

  const rawSuggestions = spell.suggest(cleanWord);
  if (rawSuggestions.length === 0) {
    // Unknown word with no close dictionary match - don't spam errors on
    // things that might be proper nouns, brand names, or jargon.
    return { isMisspelled: false };
  }

  const cased = rawSuggestions.slice(0, MAX_SPELLING_SUGGESTIONS).map(applyCasing);
  return {
    isMisspelled: true,
    suggestion: cased[0],
    alternatives: cased.length > 1 ? cased.slice(1) : undefined,
  };
}


export async function checkText(
  text: string,
  customDict: string[],
  ignoredWords: string[],
  enabledRules: { [ruleId: string]: boolean }
): Promise<{ suggestions: Suggestion[]; logs: SystemLog[] }> {
  const startTime = performance.now();
  const suggestions: Suggestion[] = [];
  const logs: SystemLog[] = [];

  const addLog = (level: 'info' | 'warn' | 'error' | 'perf', module: SystemLog['module'], message: string, duration?: number) => {
    logs.push({
      id: Math.random().toString(36).substring(7),
      timestamp: new Date().toISOString(),
      level,
      module,
      message,
      durationMs: duration,
    });
  };

  addLog('info', 'GrammarEngine', `Starting analysis on ${text.length} characters of text.`);

  if (!text.trim()) {
    const elapsed = performance.now() - startTime;
    addLog('perf', 'GrammarEngine', 'Analysis completed on empty text.', elapsed);
    return { suggestions, logs };
  }

  // --- 1. DUPLICATE SPACES RULE ---
  if (enabledRules['duplicate-spaces']) {
    const ruleStart = performance.now();
    const regex = /[ ]{2,}/g;
    let match;
    while ((match = regex.exec(text)) !== null) {
      suggestions.push({
        id: `dup-space-${match.index}`,
        ruleId: 'duplicate-spaces',
        ruleName: 'Duplicate Spaces',
        originalText: match[0],
        suggestedText: ' ',
        startIndex: match.index,
        endIndex: match.index + match[0].length,
        explanation: 'Multiple consecutive spaces are redundant. Replace with a single space.',
        type: 'warning',
      });
    }
    addLog('perf', 'GrammarEngine', 'Duplicate spaces rule executed.', performance.now() - ruleStart);
  }

  // --- 2. TRAILING WHITESPACE / WHITESPACE CLEANUP ---
  if (enabledRules['whitespace-cleanup']) {
    const ruleStart = performance.now();
    const regex = /[ \t]+$/gm;
    let match;
    while ((match = regex.exec(text)) !== null) {
      suggestions.push({
        id: `trailing-space-${match.index}`,
        ruleId: 'whitespace-cleanup',
        ruleName: 'Trailing Whitespace',
        originalText: match[0],
        suggestedText: '',
        startIndex: match.index,
        endIndex: match.index + match[0].length,
        explanation: 'Unnecessary spaces at the end of the line. Remove them.',
        type: 'info',
      });
    }
    addLog('perf', 'GrammarEngine', 'Whitespace cleanup rule executed.', performance.now() - ruleStart);
  }

  // --- 3. BASIC PUNCTUATION SPACING ---
  if (enabledRules['basic-punctuation']) {
    const ruleStart = performance.now();
    
    // Space before punctuation: e.g. "hello , world" -> "hello, world"
    const spacingBeforeRegex = /(\s+)([,\.\?!;:])(\s*)/g;
    let match;
    while ((match = spacingBeforeRegex.exec(text)) !== null) {
      const badSpaces = match[1];
      const punctuation = match[2];
      const afterSpaces = match[3];
      
      const startIndex = match.index;
      const endIndex = match.index + match[0].length;
      
      const correctText = punctuation + (afterSpaces === '' && punctuation !== '.' ? ' ' : afterSpaces);
      
      suggestions.push({
        id: `punc-space-before-${startIndex}`,
        ruleId: 'basic-punctuation',
        ruleName: 'Space Before Punctuation',
        originalText: match[0],
        suggestedText: punctuation + (afterSpaces || (punctuation !== '.' && punctuation !== '?' && punctuation !== '!' ? ' ' : '')),
        startIndex,
        endIndex,
        explanation: `Do not put spaces before a ${punctuation === ',' ? 'comma' : punctuation === '.' ? 'period' : 'punctuation mark'}.`,
        type: 'warning',
      });
    }

    // Missing space after punctuation: e.g., "hello,world" -> "hello, world"
    // We avoid matching numbers like "1.5" or web domains like "google.com"
    const missingSpaceRegex = /([a-zA-Z0-9])([,\?!;:])([a-zA-Z])/g;
    while ((match = missingSpaceRegex.exec(text)) !== null) {
      const charBefore = match[1];
      const punctuation = match[2];
      const charAfter = match[3];
      
      suggestions.push({
        id: `punc-space-missing-${match.index}`,
        ruleId: 'basic-punctuation',
        ruleName: 'Missing Space After Punctuation',
        originalText: match[0],
        suggestedText: `${charBefore}${punctuation} ${charAfter}`,
        startIndex: match.index,
        endIndex: match.index + match[0].length,
        explanation: `Add a space after the ${punctuation === ',' ? 'comma' : punctuation === '.' ? 'period' : 'punctuation mark'}.`,
        type: 'warning',
      });
    }

    addLog('perf', 'GrammarEngine', 'Punctuation spacing rules executed.', performance.now() - ruleStart);
  }

  // Helper arrays/structures for processing words & sentences
  // Split into sentence-like blocks while preserving indexes
  const sentenceRegex = /[^.!?]+[.!?]*\s*/g;
  let sentenceMatch;
  
  while ((sentenceMatch = sentenceRegex.exec(text)) !== null) {
    const sentenceText = sentenceMatch[0];
    const sentenceStart = sentenceMatch.index;
    const sentenceEnd = sentenceStart + sentenceText.length;

    // --- 4. SENTENCE CAPITALIZATION ---
    if (enabledRules['sentence-capitalization']) {
      const trimmedSentence = sentenceText.trimStart();
      const leadingSpacesCount = sentenceText.length - trimmedSentence.length;
      const firstCharIndex = sentenceStart + leadingSpacesCount;
      
      if (firstCharIndex < text.length) {
        const firstChar = text.charAt(firstCharIndex);
        // Only capitalize actual alphabetic lowercase letters
        if (/[a-z]/.test(firstChar)) {
          // Double check if it is the start of the whole text, or follows a sentence punctuation
          let isRealSentenceStart = false;
          if (firstCharIndex === 0) {
            isRealSentenceStart = true;
          } else {
            // Check preceding non-whitespace characters
            const precedingText = text.substring(0, firstCharIndex).trimEnd();
            if (precedingText.length > 0) {
              const lastChar = precedingText.charAt(precedingText.length - 1);
              if (['.', '!', '?'].includes(lastChar)) {
                // Ensure it's not a common abbreviation like "e.g.", "i.e.", "vs."
                const isAbbreviation = /\b(e\.g|i\.e|vs|approx|min|max|etc)\.$/i.test(precedingText);
                if (!isAbbreviation) {
                  isRealSentenceStart = true;
                }
              }
            }
          }

          if (isRealSentenceStart) {
            suggestions.push({
              id: `sentence-cap-${firstCharIndex}`,
              ruleId: 'sentence-capitalization',
              ruleName: 'Sentence Capitalization',
              originalText: firstChar,
              suggestedText: firstChar.toUpperCase(),
              startIndex: firstCharIndex,
              endIndex: firstCharIndex + 1,
              explanation: 'A sentence must start with a capital letter.',
              type: 'error',
            });
          }
        }
      }
    }

    // Tokenize sentence into word tokens
    // We match individual words and track their position
    const wordRegex = /\b[a-zA-Z']+\b/g;
    let wordMatch;
    const tokens: { word: string; start: number; end: number }[] = [];

    while ((wordMatch = wordRegex.exec(sentenceText)) !== null) {
      tokens.push({
        word: wordMatch[0],
        start: sentenceStart + wordMatch.index,
        end: sentenceStart + wordMatch.index + wordMatch[0].length,
      });
    }

    // Process tokens
    for (let i = 0; i < tokens.length; i++) {
      const currentToken = tokens[i];
      const word = currentToken.word;
      const lowerWord = word.toLowerCase();

      // --- 5. REPEATED WORDS RULE ---
      if (enabledRules['repeated-words'] && i < tokens.length - 1) {
        const nextToken = tokens[i + 1];
        if (lowerWord === nextToken.word.toLowerCase()) {
          // Check if there are only spaces between them
          const intermediateText = text.substring(currentToken.end, nextToken.start);
          if (/^\s*$/.test(intermediateText)) {
            suggestions.push({
              id: `repeated-word-${currentToken.start}`,
              ruleId: 'repeated-words',
              ruleName: 'Repeated Word',
              originalText: `${word}${intermediateText}${nextToken.word}`,
              suggestedText: word,
              startIndex: currentToken.start,
              endIndex: nextToken.end,
              explanation: `Double word "${word}". Remove the repeated word.`,
              type: 'warning',
            });
            // Skip next word to avoid cascading checks on same duplicate
            i++;
            continue;
          }
        }
      }

      // --- 6. COMMON SPELLING RULE ---
      if (enabledRules['common-spelling']) {
        const spellResult = await checkSpelling(word, customDict, ignoredWords);
        if (spellResult.isMisspelled && spellResult.suggestion) {
          suggestions.push({
            id: `spelling-${currentToken.start}`,
            ruleId: 'common-spelling',
            ruleName: 'Spelling Error',
            originalText: word,
            suggestedText: spellResult.suggestion,
            startIndex: currentToken.start,
            endIndex: currentToken.end,
            explanation: `"${word}" is misspelled. Did you mean "${spellResult.suggestion}"?`,
            type: 'error',
            alternatives: spellResult.alternatives,
          });
        }
      }

      // --- 7. SUBJECT-VERB AGREEMENT RULES ---
      if (enabledRules['subject-verb-agreement']) {
        if (i < tokens.length - 1) {
          const nextToken = tokens[i + 1];
          const nextWord = nextToken.word.toLowerCase();
          const agreementStart = currentToken.start;
          const agreementEnd = nextToken.end;

          const originalPhrase = text.substring(agreementStart, agreementEnd);

          // We check standard bad pairings
          // They + singular verb or bad forms
          if (lowerWord === 'they' || lowerWord === 'we' || lowerWord === 'you') {
            if (nextWord === 'is' || nextWord === 'am') {
              suggestions.push({
                id: `sva-${agreementStart}`,
                ruleId: 'subject-verb-agreement',
                ruleName: 'Subject-Verb Agreement',
                originalText: originalPhrase,
                suggestedText: word + originalPhrase.substring(word.length).replace(/(is|am)/i, 'are'),
                startIndex: agreementStart,
                endIndex: agreementEnd,
                explanation: `Plural pronoun "${word}" requires plural verb "are", not "${nextToken.word}".`,
                type: 'error',
              });
            } else if (nextWord === 'was') {
              suggestions.push({
                id: `sva-${agreementStart}`,
                ruleId: 'subject-verb-agreement',
                ruleName: 'Subject-Verb Agreement',
                originalText: originalPhrase,
                suggestedText: word + originalPhrase.substring(word.length).replace(/was/i, 'were'),
                startIndex: agreementStart,
                endIndex: agreementEnd,
                explanation: `Plural pronoun "${word}" requires plural verb "were", not "was".`,
                type: 'error',
              });
            } else if (nextWord === 'has') {
              suggestions.push({
                id: `sva-${agreementStart}`,
                ruleId: 'subject-verb-agreement',
                ruleName: 'Subject-Verb Agreement',
                originalText: originalPhrase,
                suggestedText: word + originalPhrase.substring(word.length).replace(/has/i, 'have'),
                startIndex: agreementStart,
                endIndex: agreementEnd,
                explanation: `Pronoun "${word}" requires verb "have", not "has".`,
                type: 'error',
              });
            } else if (nextWord === 'goes') {
              suggestions.push({
                id: `sva-${agreementStart}`,
                ruleId: 'subject-verb-agreement',
                ruleName: 'Subject-Verb Agreement',
                originalText: originalPhrase,
                suggestedText: word + originalPhrase.substring(word.length).replace(/goes/i, 'go'),
                startIndex: agreementStart,
                endIndex: agreementEnd,
                explanation: `Pronoun "${word}" requires verb "go", not "goes".`,
                type: 'error',
              });
            }
          }

          // He/She/It + plural verb
          if (lowerWord === 'he' || lowerWord === 'she' || lowerWord === 'it') {
            if (nextWord === 'go') {
              suggestions.push({
                id: `sva-${agreementStart}`,
                ruleId: 'subject-verb-agreement',
                ruleName: 'Subject-Verb Agreement',
                originalText: originalPhrase,
                suggestedText: word + originalPhrase.substring(word.length).replace(/go/i, 'goes'),
                startIndex: agreementStart,
                endIndex: agreementEnd,
                explanation: `Singular pronoun "${word}" requires verb "goes", not "go".`,
                type: 'error',
              });
            } else if (nextWord === 'have') {
              suggestions.push({
                id: `sva-${agreementStart}`,
                ruleId: 'subject-verb-agreement',
                ruleName: 'Subject-Verb Agreement',
                originalText: originalPhrase,
                suggestedText: word + originalPhrase.substring(word.length).replace(/have/i, 'has'),
                startIndex: agreementStart,
                endIndex: agreementEnd,
                explanation: `Singular pronoun "${word}" requires verb "has", not "have".`,
                type: 'error',
              });
            } else if (nextWord === 'do') {
              suggestions.push({
                id: `sva-${agreementStart}`,
                ruleId: 'subject-verb-agreement',
                ruleName: 'Subject-Verb Agreement',
                originalText: originalPhrase,
                suggestedText: word + originalPhrase.substring(word.length).replace(/do/i, 'does'),
                startIndex: agreementStart,
                endIndex: agreementEnd,
                explanation: `Singular pronoun "${word}" requires verb "does", not "do".`,
                type: 'error',
              });
            } else if (nextWord === 'are' || nextWord === 'am') {
              suggestions.push({
                id: `sva-${agreementStart}`,
                ruleId: 'subject-verb-agreement',
                ruleName: 'Subject-Verb Agreement',
                originalText: originalPhrase,
                suggestedText: word + originalPhrase.substring(word.length).replace(/(are|am)/i, 'is'),
                startIndex: agreementStart,
                endIndex: agreementEnd,
                explanation: `Singular pronoun "${word}" requires verb "is", not "${nextToken.word}".`,
                type: 'error',
              });
            } else if (nextWord === 'were') {
              suggestions.push({
                id: `sva-${agreementStart}`,
                ruleId: 'subject-verb-agreement',
                ruleName: 'Subject-Verb Agreement',
                originalText: originalPhrase,
                suggestedText: word + originalPhrase.substring(word.length).replace(/were/i, 'was'),
                startIndex: agreementStart,
                endIndex: agreementEnd,
                explanation: `Singular pronoun "${word}" requires verb "was", not "were".`,
                type: 'error',
              });
            }
          }

          // Pronoun "I" combinations
          if (lowerWord === 'i') {
            if (nextWord === 'is' || nextWord === 'are') {
              suggestions.push({
                id: `sva-${agreementStart}`,
                ruleId: 'subject-verb-agreement',
                ruleName: 'Subject-Verb Agreement',
                originalText: originalPhrase,
                suggestedText: word + originalPhrase.substring(word.length).replace(/(is|are)/i, 'am'),
                startIndex: agreementStart,
                endIndex: agreementEnd,
                explanation: 'Pronoun "I" takes "am".',
                type: 'error',
              });
            } else if (nextWord === 'were') {
              suggestions.push({
                id: `sva-${agreementStart}`,
                ruleId: 'subject-verb-agreement',
                ruleName: 'Subject-Verb Agreement',
                originalText: originalPhrase,
                suggestedText: word + originalPhrase.substring(word.length).replace(/were/i, 'was'),
                startIndex: agreementStart,
                endIndex: agreementEnd,
                explanation: 'Pronoun "I" takes "was", not "were" in standard active past tense.',
                type: 'error',
              });
            } else if (nextWord === 'goes') {
              suggestions.push({
                id: `sva-${agreementStart}`,
                ruleId: 'subject-verb-agreement',
                ruleName: 'Subject-Verb Agreement',
                originalText: originalPhrase,
                suggestedText: word + originalPhrase.substring(word.length).replace(/goes/i, 'go'),
                startIndex: agreementStart,
                endIndex: agreementEnd,
                explanation: 'Pronoun "I" takes "go", not "goes".',
                type: 'error',
              });
            }
          }

          // Modal verbs ("would", "will", "could", "should", "might", "must")
          // followed by "has"/"was" (should be the base form "have"), or the
          // very common homophone mistake "of" instead of "have"
          // (e.g. "would of" -> "would have", "he would has finished" -> "he would have finished").
          const modalVerbs = new Set(['would', 'will', 'could', 'should', 'might', 'must']);
          if (modalVerbs.has(lowerWord)) {
            if (nextWord === 'of' || nextWord === 'has' || nextWord === 'was') {
              suggestions.push({
                id: `sva-modal-${agreementStart}`,
                ruleId: 'subject-verb-agreement',
                ruleName: 'Modal Verb Agreement',
                originalText: originalPhrase,
                suggestedText: word + ' have',
                startIndex: agreementStart,
                endIndex: agreementEnd,
                explanation: `"${word} ${nextToken.word}" should be "${word} have" (modal verbs like "${word}" are always followed by the base form "have", not "${nextToken.word}").`,
                type: 'error',
              });
            }
          }

          // "don't" / "doesn't" agreement
          // Singular third person (he/she/it) takes "doesn't"; everything else takes "don't".
          if (nextWord === "don't" && (lowerWord === 'he' || lowerWord === 'she' || lowerWord === 'it')) {
            suggestions.push({
              id: `sva-dont-${agreementStart}`,
              ruleId: 'subject-verb-agreement',
              ruleName: 'Subject-Verb Agreement',
              originalText: originalPhrase,
              suggestedText: word + " doesn't",
              startIndex: agreementStart,
              endIndex: agreementEnd,
              explanation: `Singular pronoun "${word}" requires "doesn't", not "don't".`,
              type: 'error',
            });
          } else if (
            nextWord === "doesn't" &&
            (lowerWord === 'i' || lowerWord === 'you' || lowerWord === 'we' || lowerWord === 'they')
          ) {
            suggestions.push({
              id: `sva-doesnt-${agreementStart}`,
              ruleId: 'subject-verb-agreement',
              ruleName: 'Subject-Verb Agreement',
              originalText: originalPhrase,
              suggestedText: word + " don't",
              startIndex: agreementStart,
              endIndex: agreementEnd,
              explanation: `Pronoun "${word}" requires "don't", not "doesn't".`,
              type: 'error',
            });
          }
        }

        // Questions starting with "where" / "who" / "what" / "when" / "why" / "how"
        const questionWords = ['where', 'who', 'what', 'when', 'why', 'how'];
        if (questionWords.includes(lowerWord)) {
          // Check for inverted subject-verb agreement (e.g. "where is they", "where is you")
          if (i < tokens.length - 2) {
            const verbToken = tokens[i + 1];
            const subjectToken = tokens[i + 2];
            const verb = verbToken.word.toLowerCase();
            const subject = subjectToken.word.toLowerCase();

            const inversionStart = currentToken.start;
            const inversionEnd = subjectToken.end;
            const originalInversion = text.substring(inversionStart, inversionEnd);

            if (subject === 'they' || subject === 'we' || subject === 'you') {
              if (verb === 'is' || verb === 'am' || verb === 'was') {
                const correctVerb = (verb === 'was') ? 'were' : 'are';
                suggestions.push({
                  id: `sva-invert-${inversionStart}`,
                  ruleId: 'subject-verb-agreement',
                  ruleName: 'Subject-Verb Agreement',
                  originalText: originalInversion,
                  suggestedText: word + ' ' + correctVerb + ' ' + subjectToken.word,
                  startIndex: inversionStart,
                  endIndex: inversionEnd,
                  explanation: `Question starting with "${word}" and subject "${subjectToken.word}" requires verb "${correctVerb}", not "${verbToken.word}".`,
                  type: 'error',
                });
              }
            } else if (subject === 'he' || subject === 'she' || subject === 'it') {
              if (verb === 'are' || verb === 'am' || verb === 'were') {
                const correctVerb = (verb === 'were') ? 'was' : 'is';
                suggestions.push({
                  id: `sva-invert-${inversionStart}`,
                  ruleId: 'subject-verb-agreement',
                  ruleName: 'Subject-Verb Agreement',
                  originalText: originalInversion,
                  suggestedText: word + ' ' + correctVerb + ' ' + subjectToken.word,
                  startIndex: inversionStart,
                  endIndex: inversionEnd,
                  explanation: `Question starting with "${word}" and subject "${subjectToken.word}" requires verb "${correctVerb}", not "${verbToken.word}".`,
                  type: 'error',
                });
              }
            } else if (subject === 'i') {
              if (verb === 'is' || verb === 'are' || verb === 'were') {
                const correctVerb = (verb === 'were') ? 'was' : 'am';
                suggestions.push({
                  id: `sva-invert-${inversionStart}`,
                  ruleId: 'subject-verb-agreement',
                  ruleName: 'Subject-Verb Agreement',
                  originalText: originalInversion,
                  suggestedText: word + ' ' + correctVerb + ' ' + subjectToken.word,
                  startIndex: inversionStart,
                  endIndex: inversionEnd,
                  explanation: `Question starting with "${word}" and subject "${subjectToken.word}" requires verb "${correctVerb}", not "${verbToken.word}".`,
                  type: 'error',
                });
              }
            }
          }

          // Check for helping/modal/be verbs word order issue (e.g. "where you will go", "where you would go", "where I am")
          if (i < tokens.length - 2) {
            const pronounToken = tokens[i + 1];
            const modalToken = tokens[i + 2];
            const pronoun = pronounToken.word.toLowerCase();
            const modal = modalToken.word.toLowerCase();

            const pronouns = ['i', 'you', 'he', 'she', 'it', 'we', 'they'];
            const modals = ['will', 'would', 'am', 'is', 'are', 'was', 'were', 'can', 'could', 'should'];

            if (pronouns.includes(pronoun) && modals.includes(modal)) {
              const inversionStart = currentToken.start;
              const inversionEnd = modalToken.end;
              const originalInversion = text.substring(inversionStart, inversionEnd);

              suggestions.push({
                id: `sva-word-order-${inversionStart}`,
                ruleId: 'subject-verb-agreement',
                ruleName: 'Question Word Order',
                originalText: originalInversion,
                suggestedText: word + ' ' + modalToken.word + ' ' + pronounToken.word,
                startIndex: inversionStart,
                endIndex: inversionEnd,
                explanation: `For direct questions starting with "${word}", invert the subject and helping verb to "${modalToken.word} ${pronounToken.word}".`,
                type: 'warning',
              });
            }
          }
        }
      }

      // --- 8. ARTICLES RULE ("a" vs "an") ---
      if (enabledRules['articles'] && i < tokens.length - 1) {
        const nextToken = tokens[i + 1];
        const nextWord = nextToken.word.toLowerCase();
        const nextWordFirstChar = nextWord.charAt(0);
        const nextWordStartsWithVowel = VOWELS.has(nextWordFirstChar);

        const phraseStart = currentToken.start;
        const phraseEnd = nextToken.end;
        const originalPhrase = text.substring(phraseStart, phraseEnd);

        if (lowerWord === 'a' && nextWordStartsWithVowel) {
          // Exceptions (like "university", "unique")
          const isException = nextWord.startsWith('uni') || nextWord.startsWith('one');
          
          if (!isException) {
            suggestions.push({
              id: `article-a-${phraseStart}`,
              ruleId: 'articles',
              ruleName: 'Incorrect Article',
              originalText: originalPhrase,
              suggestedText: originalPhrase.replace(/^a/i, word[0] === 'A' ? 'An' : 'an'),
              startIndex: phraseStart,
              endIndex: phraseEnd,
              explanation: `Use "an" before words starting with a vowel sound: "${nextWord}".`,
              type: 'error',
            });
          }
        } else if (lowerWord === 'an' && !nextWordStartsWithVowel) {
          // Exceptions (like "hour", "honest")
          const isException = nextWord.startsWith('hour') || nextWord.startsWith('honest') || nextWord.startsWith('honor');
          
          if (!isException) {
            suggestions.push({
              id: `article-an-${phraseStart}`,
              ruleId: 'articles',
              ruleName: 'Incorrect Article',
              originalText: originalPhrase,
              suggestedText: originalPhrase.replace(/^an/i, word[0] === 'A' ? 'A' : 'a'),
              startIndex: phraseStart,
              endIndex: phraseEnd,
              explanation: `Use "a" before words starting with a consonant sound: "${nextWord}".`,
              type: 'error',
            });
          }
        }
      }

      // --- 9. PROPER CAPITALIZATION RULE ---
      if (enabledRules['capitalization']) {
        // Pronoun "I" must be capitalized
        if (word === 'i') {
          suggestions.push({
            id: `cap-i-${currentToken.start}`,
            ruleId: 'capitalization',
            ruleName: 'Capitalization of "I"',
            originalText: word,
            suggestedText: 'I',
            startIndex: currentToken.start,
            endIndex: currentToken.end,
            explanation: 'The pronoun "I" should always be capitalized.',
            type: 'error',
          });
        }

        // Days of week and months, or proper languages
        const PROPER_NOUNS = new Set([
          'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday',
          'january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december',
          'english', 'french', 'german', 'spanish', 'italian', 'japanese', 'chinese', 'russian',
          'linux', 'ubuntu', 'fedora', 'debian', 'mint'
        ]);

        if (PROPER_NOUNS.has(lowerWord) && word !== lowerWord.charAt(0).toUpperCase() + lowerWord.slice(1)) {
          const capitalized = lowerWord.charAt(0).toUpperCase() + lowerWord.slice(1);
          suggestions.push({
            id: `cap-proper-${currentToken.start}`,
            ruleId: 'capitalization',
            ruleName: 'Capitalization of Proper Noun',
            originalText: word,
            suggestedText: capitalized,
            startIndex: currentToken.start,
            endIndex: currentToken.end,
            explanation: `"${capitalized}" is a proper noun or language and must be capitalized.`,
            type: 'warning',
          });
        }
      }
    }
  }

  // Sort suggestions by starting index to avoid misalignment
  suggestions.sort((a, b) => a.startIndex - b.startIndex);

  const durationMs = performance.now() - startTime;
  addLog(
    durationMs > 100 ? 'warn' : 'perf',
    'GrammarEngine',
    `Analysis complete. Found ${suggestions.length} suggestions across ${text.split(/\s+/).length} words.`,
    durationMs
  );

  return { suggestions, logs };
}
