import React, { useState, useEffect } from 'react';
import DesktopWindow from './components/DesktopWindow';
import Sidebar from './components/Sidebar';
import WritingCanvas from './components/WritingCanvas';
import RulesManager from './components/RulesManager';
import DictionaryManager from './components/DictionaryManager';
import StatsDashboard from './components/StatsDashboard';
import SettingsPanel from './components/SettingsPanel';
import DatabaseConsole from './components/DatabaseConsole';
import { AppSettings, SystemLog, WritingStats } from './types';

// Default application preferences conforming to user requested defaults
const DEFAULT_SETTINGS: AppSettings = {
  popupDelay: 300,
  popupSize: 'medium',
  fontSize: 'medium',
  autoCorrection: true,
  launchOnStartup: true,
  theme: 'dark',
  hotkeyAccept: 'Alt+A',
  hotkeyIgnore: 'Alt+I',
  enabledRules: {
    'subject-verb-agreement': true,
    'articles': true,
    'capitalization': true,
    'sentence-capitalization': true,
    'duplicate-spaces': true,
    'repeated-words': true,
    'basic-punctuation': true,
    'common-spelling': true,
    'whitespace-cleanup': false,
  },
  engineMode: 'dynamic',
};

const INITIAL_LOGS: SystemLog[] = [
  {
    id: 'init-1',
    timestamp: new Date(Date.now() - 30000).toISOString(),
    level: 'info',
    module: 'Database',
    message: 'Loading SQLite database at ~/.config/ga/db.sqlite. Connection established (v3.42.0).',
  },
  {
    id: 'init-2',
    timestamp: new Date(Date.now() - 28000).toISOString(),
    level: 'info',
    module: 'Settings',
    message: 'Loaded persistent setting schema: startup=1, theme=dark, popup_delay=300ms.',
  },
  {
    id: 'init-3',
    timestamp: new Date(Date.now() - 25000).toISOString(),
    level: 'info',
    module: 'GrammarEngine',
    message: 'Initialized grammar rule matching matrices (9 active categories). SymSpell dictionary cached (32k keys).',
  },
  {
    id: 'init-4',
    timestamp: new Date(Date.now() - 20000).toISOString(),
    level: 'info',
    module: 'Tray',
    message: 'GNOME desktop integration daemon listening on Wayland accessibility AT-SPI socket.',
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('editor');
  
  // 1. Settings state
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('ga_settings');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error(e);
      }
    }
    return DEFAULT_SETTINGS;
  });

  // 2. Custom Dictionary state
  const [customDict, setCustomDict] = useState<string[]>(() => {
    const saved = localStorage.getItem('ga_custom_dict');
    return saved ? JSON.parse(saved) : ['React', 'Electron', 'Vite', 'Wayland', 'Fedora'];
  });

  // 3. Ignored Words state
  const [ignoredWords, setIgnoredWords] = useState<string[]>(() => {
    const saved = localStorage.getItem('ga_ignored_words');
    return saved ? JSON.parse(saved) : ['localhost', 'npm', 'esbuild'];
  });

  // 4. Writing statistics state
  const [stats, setStats] = useState<WritingStats>(() => {
    const saved = localStorage.getItem('ga_stats');
    return saved ? JSON.parse(saved) : {
      wordsAnalyzed: 284,
      correctionsAccepted: 45,
      correctionsIgnored: 8,
      errorDistribution: {
        'subject-verb-agreement': 12,
        'articles': 8,
        'common-spelling': 15,
        'sentence-capitalization': 5,
        'duplicate-spaces': 10,
      }
    };
  });

  // 5. System Logs state
  const [logs, setLogs] = useState<SystemLog[]>(INITIAL_LOGS);

  // Sync state helpers
  useEffect(() => {
    localStorage.setItem('ga_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('ga_custom_dict', JSON.stringify(customDict));
  }, [customDict]);

  useEffect(() => {
    localStorage.setItem('ga_ignored_words', JSON.stringify(ignoredWords));
  }, [ignoredWords]);

  useEffect(() => {
    localStorage.setItem('ga_stats', JSON.stringify(stats));
  }, [stats]);

  // Log append helper
  const addLogs = (newLogs: SystemLog[]) => {
    setLogs(prev => [...prev, ...newLogs].slice(-400)); // cap at 400 logs to save memory
  };

  const clearLogs = () => {
    setLogs([
      {
        id: Math.random().toString(),
        timestamp: new Date().toISOString(),
        level: 'info',
        module: 'Settings',
        message: 'Cleared terminal system log cache.',
      }
    ]);
  };

  // Settings Updater
  const updateSetting = <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  // Toggle specific grammar rules
  const toggleRule = (ruleId: string) => {
    setSettings(prev => {
      const updatedRules = { ...prev.enabledRules };
      updatedRules[ruleId] = updatedRules[ruleId] === false ? true : false;
      return {
        ...prev,
        enabledRules: updatedRules
      };
    });
  };

  // Dictionary helpers
  const addToCustomDict = (word: string) => {
    if (!word) return;
    setCustomDict(prev => [...prev.filter(w => w.toLowerCase() !== word.toLowerCase()), word]);
  };

  const removeFromCustomDict = (word: string) => {
    setCustomDict(prev => prev.filter(w => w !== word));
  };

  const addToIgnoredWords = (word: string) => {
    if (!word) return;
    setIgnoredWords(prev => [...prev.filter(w => w.toLowerCase() !== word.toLowerCase()), word]);
  };

  const removeFromIgnoredWords = (word: string) => {
    setIgnoredWords(prev => prev.filter(w => w !== word));
  };

  // Stats Counters Increments
  const incrementStats = (accepted: boolean, category: string) => {
    setStats(prev => {
      const updatedDistribution = { ...prev.errorDistribution };
      updatedDistribution[category] = (updatedDistribution[category] || 0) + 1;

      return {
        wordsAnalyzed: prev.wordsAnalyzed + 1, // we increment checked counters
        correctionsAccepted: accepted ? prev.correctionsAccepted + 1 : prev.correctionsAccepted,
        correctionsIgnored: !accepted ? prev.correctionsIgnored + 1 : prev.correctionsIgnored,
        errorDistribution: updatedDistribution
      };
    });
  };

  const resetStats = () => {
    setStats({
      wordsAnalyzed: 0,
      correctionsAccepted: 0,
      correctionsIgnored: 0,
      errorDistribution: {
        'subject-verb-agreement': 0,
        'articles': 0,
        'common-spelling': 0,
        'sentence-capitalization': 0,
        'duplicate-spaces': 0,
      }
    });
  };

  return (
    <DesktopWindow
      settings={settings}
      updateSetting={updateSetting}
      logs={logs}
      clearLogs={clearLogs}
      onNavigate={setActiveTab}
      activeTab={activeTab}
    >
      {/* Sidebar navigation */}
      <Sidebar 
        activeTab={activeTab} 
        onNavigate={setActiveTab} 
        settings={settings} 
      />

      {/* Main active sub-workspace panels */}
      <div className="flex-1 flex flex-col min-h-0 bg-[#0F1115]">
        {activeTab === 'editor' && (
          <WritingCanvas
            settings={settings}
            updateSetting={updateSetting}
            customDict={customDict}
            addToCustomDict={addToCustomDict}
            ignoredWords={ignoredWords}
            addToIgnoredWords={addToIgnoredWords}
            logs={logs}
            addLogs={addLogs}
            incrementStats={incrementStats}
          />
        )}

        {activeTab === 'rules' && (
          <RulesManager
            settings={settings}
            toggleRule={toggleRule}
            addLogs={addLogs}
          />
        )}

        {activeTab === 'dictionary' && (
          <DictionaryManager
            settings={settings}
            customDict={customDict}
            addToCustomDict={addToCustomDict}
            removeFromCustomDict={removeFromCustomDict}
            ignoredWords={ignoredWords}
            addToIgnoredWords={addToIgnoredWords}
            removeFromIgnoredWords={removeFromIgnoredWords}
            addLogs={addLogs}
          />
        )}

        {activeTab === 'stats' && (
          <StatsDashboard
            settings={settings}
            stats={stats}
            resetStats={resetStats}
            addLogs={addLogs}
          />
        )}

        {activeTab === 'settings' && (
          <SettingsPanel
            settings={settings}
            updateSetting={updateSetting}
            addLogs={addLogs}
          />
        )}

        {activeTab === 'database' && (
          <DatabaseConsole
            settings={settings}
            logs={logs}
            clearLogs={clearLogs}
            customDict={customDict}
            ignoredWords={ignoredWords}
            stats={stats}
          />
        )}
      </div>
    </DesktopWindow>
  );
}
