import React, { useState, useEffect } from 'react';
import { 
  Terminal, 
  Cpu, 
  Database, 
  WifiOff, 
  Bell, 
  Clock, 
  ChevronDown, 
  Settings, 
  BarChart2, 
  Maximize2, 
  Minimize2, 
  X, 
  Info,
  CheckCircle,
  HelpCircle,
  BookOpen,
  Sparkles,
  Wifi
} from 'lucide-react';
import { AppSettings, SystemLog } from '../types';

interface DesktopWindowProps {
  children: React.ReactNode;
  settings: AppSettings;
  updateSetting: <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => void;
  logs: SystemLog[];
  clearLogs: () => void;
  onNavigate: (tab: string) => void;
  activeTab: string;
}

export default function DesktopWindow({
  children,
  settings,
  updateSetting,
  logs,
  clearLogs,
  onNavigate,
  activeTab,
}: DesktopWindowProps) {
  const [time, setTime] = useState<string>('');
  const [trayOpen, setTrayOpen] = useState(false);
  const [simulatedCpu, setSimulatedCpu] = useState(0.2);
  const [simulatedMemory, setSimulatedMemory] = useState(42.5);
  const [showNotification, setShowNotification] = useState<string | null>(null);

  // Update clock
  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  // Simulate subtle CPU & Memory fluctuations of an offline daemon
  useEffect(() => {
    const interval = setInterval(() => {
      setSimulatedCpu(prev => {
        const delta = (Math.random() - 0.5) * 0.1;
        const target = Math.max(0.1, Math.min(1.8, prev + delta));
        return parseFloat(target.toFixed(1));
      });
      setSimulatedMemory(prev => {
        const delta = (Math.random() - 0.5) * 0.5;
        const target = Math.max(38.0, Math.min(46.0, prev + delta));
        return parseFloat(target.toFixed(1));
      });
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  // Show tray notification helper
  const triggerNotification = (message: string) => {
    setShowNotification(message);
    setTimeout(() => {
      setShowNotification(null);
    }, 4000);
  };

  const toggleTheme = () => {
    const newTheme = settings.theme === 'dark' ? 'light' : 'dark';
    updateSetting('theme', newTheme);
    triggerNotification(`Switched to ${newTheme === 'dark' ? 'Dark' : 'Light'} Mode theme.`);
  };

  return (
    <div id="desktop-root" className={`min-h-screen flex flex-col font-sans select-none overflow-hidden transition-colors duration-200 ${
      settings.theme === 'dark' ? 'bg-[#0F1115] text-[#E0E0E0]' : 'bg-[#f4f4f7] text-slate-800'
    }`}>
      
      {/* 1. Ubuntu GNOME/Pop!_OS Top Bar */}
      <header id="gnome-topbar" className="h-8 bg-[#12141A] text-xs text-[#8E9299] px-4 flex items-center justify-between border-b border-[#2A2D35] z-50">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 font-medium text-[#E0E0E0]">
            <BookOpen className="w-3.5 h-3.5 text-[#4CAF50]" />
            <span>Grammar Assistant</span>
            <span className="px-1.5 py-0.25 text-[10px] bg-[#2D6A4F]/20 text-[#4CAF50] border border-[#2D6A4F]/30 rounded">
              v0.1
            </span>
          </div>
          <span className="text-slate-600">|</span>
          {settings.engineMode === 'dynamic' ? (
            <div className="hidden md:flex items-center gap-1.5 text-purple-400">
              <Sparkles className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
              <span className="font-semibold">Dynamic AI Mode</span>
            </div>
          ) : (
            <div className="hidden md:flex items-center gap-1.5 text-slate-400">
              <WifiOff className="w-3.5 h-3.5 text-amber-500" />
              <span>Local Engine</span>
            </div>
          )}
        </div>

        {/* Calendar / Clock Trigger */}
        <div className="absolute left-1/2 -translate-x-1/2 flex items-center gap-1.5 font-medium text-slate-200 hover:text-white cursor-pointer transition-colors px-2 py-0.5 rounded hover:bg-white/5">
          <Clock className="w-3.5 h-3.5 text-slate-400" />
          <span>{time || '12:00 PM'}</span>
        </div>

        {/* System Status Indicators (System Tray) */}
        <div className="flex items-center gap-3">
          <div className="hidden sm:flex items-center gap-3 text-slate-400">
            <div className="flex items-center gap-1">
              <Cpu className="w-3 h-3 text-slate-500" />
              <span>CPU: {simulatedCpu}%</span>
            </div>
            <div className="flex items-center gap-1">
              <Database className="w-3 h-3 text-slate-500" />
              <span>Mem: {simulatedMemory} MB</span>
            </div>
          </div>
          
          <span className="text-slate-600 hidden sm:inline">|</span>

          {/* Quick Settings Dropdown */}
          <div className="relative">
            <button 
              id="tray-toggle-btn"
              onClick={() => setTrayOpen(!trayOpen)}
              className="flex items-center gap-1 px-2 py-0.5 rounded bg-[#1C1F26] border border-[#2A2D35] hover:bg-[#2A2D35] text-[#E0E0E0] transition-colors cursor-pointer"
            >
              <Terminal className="w-3.5 h-3.5 text-[#4CAF50]" />
              <span>System</span>
              <ChevronDown className="w-3 h-3" />
            </button>

            {/* Tray Popover Panel */}
            {trayOpen && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setTrayOpen(false)} />
                <div className="absolute right-0 mt-1.5 w-64 bg-[#1A1C21] border border-[#2A2D35] rounded-lg shadow-xl py-3 px-4 text-xs text-[#E0E0E0] z-50">
                  <div className="flex justify-between items-center mb-3 border-b border-[#2A2D35] pb-2">
                    <span className="font-semibold text-[#E0E0E0]">
                      {settings.engineMode === 'dynamic' ? 'Dynamic Daemon Status' : 'Offline Daemon Status'}
                    </span>
                    <span className={`px-1.5 py-0.5 rounded-full ${
                      settings.engineMode === 'dynamic'
                        ? 'bg-purple-950/40 text-purple-300 border-purple-500/30'
                        : 'bg-[#2D6A4F]/20 text-[#4CAF50] border-[#2D6A4F]/30'
                    } text-[10px] font-medium flex items-center gap-1`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${
                        settings.engineMode === 'dynamic' ? 'bg-purple-400 shadow-[0_0_8px_#a855f7]' : 'bg-[#4CAF50]'
                      } animate-pulse`} />
                      Active
                    </span>
                  </div>

                  <div className="space-y-2.5 mb-3">
                    <div className="flex justify-between">
                      <span className="text-[#8E9299]">Service:</span>
                      <span className="font-mono text-[#E0E0E0]">grammar-assistantd</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#8E9299]">Local Socket:</span>
                      <span className="font-mono text-[#E0E0E0]">/run/user/1000/ga.sock</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#8E9299]">SQLite Database:</span>
                      <span className="font-mono text-[#E0E0E0]">~/.config/ga/db.sqlite</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#8E9299]">Memory Footprint:</span>
                      <span className="font-mono text-[#4CAF50]">{simulatedMemory} MB</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#8E9299]">Process CPU:</span>
                      <span className="font-mono text-[#4CAF50]">{simulatedCpu}%</span>
                    </div>
                  </div>

                  <div className="border-t border-[#2A2D35] pt-2.5 flex flex-col gap-1.5">
                    <button 
                      onClick={() => {
                        toggleTheme();
                        setTrayOpen(false);
                      }}
                      className="w-full text-left py-1.5 px-2 hover:bg-[#1C1F26] rounded text-[#E0E0E0] transition-colors flex items-center justify-between"
                    >
                      <span>Toggle UI Theme</span>
                      <span className="text-[10px] bg-[#2A2D35] text-white px-1.5 py-0.5 rounded">
                        {settings.theme === 'dark' ? 'Light' : 'Dark'}
                      </span>
                    </button>
                    <button 
                      onClick={() => {
                        onNavigate('database');
                        setTrayOpen(false);
                      }}
                      className="w-full text-left py-1.5 px-2 hover:bg-[#1C1F26] rounded text-[#E0E0E0] transition-colors flex items-center justify-between"
                    >
                      <span>Show SQLite Console</span>
                      <Database className="w-3 h-3 text-[#8E9299]" />
                    </button>
                    <button 
                      onClick={() => {
                        onNavigate('settings');
                        setTrayOpen(false);
                      }}
                      className="w-full text-left py-1.5 px-2 hover:bg-[#1C1F26] rounded text-[#E0E0E0] transition-colors flex items-center justify-between"
                    >
                      <span>Daemon Settings</span>
                      <Settings className="w-3 h-3 text-[#8E9299]" />
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </header>

      {/* 2. Client Side Desktop Window Header (Simulated App Header) */}
      <main className="flex-1 flex flex-col min-h-0 relative">
        {/* Floating Notification */}
        {showNotification && (
          <div className="absolute top-4 right-4 z-[999] bg-slate-900 border border-slate-700/50 text-slate-100 px-4 py-3 rounded-lg shadow-2xl flex items-center gap-3 animate-bounce">
            <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <div className="text-xs font-medium">{showNotification}</div>
          </div>
        )}

        {/* Linux-style App Window Container */}
        <div className="flex-1 flex flex-col md:flex-row min-h-0 bg-[#0F1115] border-t border-[#2A2D35]">
          {children}
        </div>
      </main>

      {/* Window Footer / Status Bar */}
      <footer id="app-footer" className={`h-6 text-[11px] px-3 border-t flex items-center justify-between transition-colors duration-200 ${
        settings.theme === 'dark' 
          ? 'bg-[#12141A] border-[#2A2D35] text-[#8E9299]' 
          : 'bg-[#ebebeb] border-slate-200 text-[#8E9299]'
      }`}>
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-[#4CAF50] inline-block" />
            <span>SQLite Connected: ok</span>
          </span>
          <span>•</span>
          <span>Rules Enabled: {Object.values(settings.enabledRules).filter(Boolean).length} / {Object.keys(settings.enabledRules).length}</span>
          <span>•</span>
          <span>Auto-correction: {settings.autoCorrection ? 'ON' : 'OFF'}</span>
        </div>
        <div className="flex items-center gap-2 font-mono text-[10px]">
          <span>Linux Wayland Interop: AT-SPI</span>
          <span>|</span>
          <span className="text-[#4CAF50] font-semibold">100% Offline (Local Protection)</span>
        </div>
      </footer>
    </div>
  );
}
