import React from 'react';
import { 
  PenTool, 
  ToggleLeft, 
  BookOpen, 
  BarChart3, 
  Sliders, 
  Terminal, 
  HelpCircle 
} from 'lucide-react';
import { AppSettings } from '../types';

interface SidebarProps {
  activeTab: string;
  onNavigate: (tab: string) => void;
  settings: AppSettings;
}

export default function Sidebar({ activeTab, onNavigate, settings }: SidebarProps) {
  const isDark = settings.theme === 'dark';

  const menuItems = [
    { id: 'editor', label: 'Writing Workspace', icon: PenTool, description: 'Core text correction canvas' },
    { id: 'rules', label: 'Grammar Rules', icon: ToggleLeft, description: 'Configure active linting rules' },
    { id: 'dictionary', label: 'Local Dictionary', icon: BookOpen, description: 'Manage custom and ignored words' },
    { id: 'stats', label: 'Writing Statistics', icon: BarChart3, description: 'Track corrections & history' },
    { id: 'settings', label: 'Preferences', icon: Sliders, description: 'Hotkey and application settings' },
    { id: 'database', label: 'SQLite Console & Logs', icon: Terminal, description: 'Inspect tables and runtime logs' },
  ];

  return (
    <aside 
      id="desktop-sidebar"
      className={`w-full md:w-64 border-b md:border-b-0 md:border-r flex flex-col justify-between flex-shrink-0 transition-colors duration-200 ${
        isDark 
          ? 'bg-[#16181D] border-[#2A2D35] text-[#E0E0E0]' 
          : 'bg-[#f0f0f4] border-slate-200 text-slate-700'
      }`}
    >
      <div className="p-4 space-y-4">
        {/* App Logo Area */}
        <div className="flex items-center gap-3 px-2 py-1">
          <div className="w-8 h-8 rounded-lg bg-[#2D6A4F] flex items-center justify-center text-white font-sans font-bold text-sm">
            G
          </div>
          <div>
            <h1 className={`text-sm font-semibold tracking-tight ${isDark ? 'text-white' : 'text-slate-950'}`}>
              Grammar Assistant
            </h1>
            <p className="text-[10px] text-[#8E9299] uppercase tracking-widest font-medium">v0.1 Milestone 1</p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="space-y-1 pt-2">
          {menuItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`sidebar-tab-${item.id}`}
                onClick={() => onNavigate(item.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-all duration-150 group text-left cursor-pointer ${
                  isActive
                    ? 'bg-[#2A2D35] text-white font-medium shadow-sm'
                    : isDark
                      ? 'hover:bg-[#1C1F26] text-[#8E9299] hover:text-[#E0E0E0]'
                      : 'hover:bg-slate-200/60 text-slate-600 hover:text-slate-950'
                }`}
              >
                <Icon className={`w-4 h-4 flex-shrink-0 ${
                  isActive 
                    ? 'text-[#4CAF50]' 
                    : isDark 
                      ? 'text-slate-500 group-hover:text-slate-300' 
                      : 'text-slate-400 group-hover:text-slate-700'
                }`} />
                <div className="truncate">
                  <div>{item.label}</div>
                </div>
              </button>
            );
          })}
        </nav>
      </div>

      {/* Linux Architecture/Credits Badge (Dynamic / Offline Engine status) */}
      <div className={`p-4 border-t text-[10px] space-y-3 ${
        isDark ? 'border-[#2A2D35] bg-[#12141A]/50' : 'border-slate-200 bg-slate-200/30'
      }`}>
        <div className={`${isDark ? 'bg-[#1C1F26] border-[#2A2D35]' : 'bg-slate-100 border-slate-200'} border rounded-xl p-3.5 space-y-2`}>
          <p className="text-[10px] text-[#8E9299] uppercase tracking-widest font-bold">
            {settings.engineMode === 'dynamic' ? 'Dynamic AI Engine' : 'Offline Engine'}
          </p>
          <div className={`flex items-center gap-2 text-xs ${settings.engineMode === 'dynamic' ? 'text-purple-400' : 'text-[#4CAF50]'}`}>
            <div className={`w-1.5 h-1.5 rounded-full ${settings.engineMode === 'dynamic' ? 'bg-purple-400 shadow-[0_0_8px_#a855f7]' : 'bg-[#4CAF50]'} animate-pulse`}></div>
            <span>{settings.engineMode === 'dynamic' ? 'Gemini AI: Active' : 'Local Rules: Active'}</span>
          </div>
        </div>

        <div className="space-y-1.5 pt-1">
          <div className="flex justify-between text-[#8E9299]">
            <span>Environment:</span>
            <span className={`font-mono font-semibold ${isDark ? 'text-[#E0E0E0]' : 'text-slate-800'}`}>Wayland/X11</span>
          </div>
          <div className="flex justify-between text-[#8E9299]">
            <span>Engine Backend:</span>
            <span className={`font-mono font-semibold ${settings.engineMode === 'dynamic' ? 'text-purple-400' : 'text-[#4CAF50]'}`}>
              {settings.engineMode === 'dynamic' ? 'Hybrid (Gemini)' : 'Offline SymSpell'}
            </span>
          </div>
          <div className="flex justify-between text-[#8E9299]">
            <span>SQLite DB:</span>
            <span className="font-mono text-[#4CAF50]">v3.42.0</span>
          </div>
        </div>
        
        <div className={`mt-2 p-2 rounded text-[9px] leading-relaxed text-[#8E9299] text-center ${
          isDark ? 'bg-black/20' : 'bg-slate-300/30'
        }`}>
          Press <kbd className="px-1 py-0.5 rounded font-mono bg-slate-700 text-white text-[8px]">{settings.hotkeyAccept}</kbd> to accept floating corrections.
        </div>
      </div>
    </aside>
  );
}
