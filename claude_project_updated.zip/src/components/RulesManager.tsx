import React from 'react';
import { 
  CheckCircle, 
  XCircle, 
  HelpCircle, 
  Sliders, 
  Cpu, 
  Code,
  ShieldCheck,
  AlertTriangle,
  Grid
} from 'lucide-react';
import { AppSettings, GrammarRule, SystemLog } from '../types';
import { INITIAL_RULES } from '../grammarEngine';

interface RulesManagerProps {
  settings: AppSettings;
  toggleRule: (ruleId: string) => void;
  addLogs: (newLogs: SystemLog[]) => void;
}

export default function RulesManager({ settings, toggleRule, addLogs }: RulesManagerProps) {
  const isDark = settings.theme === 'dark';

  const handleToggle = (rule: GrammarRule) => {
    toggleRule(rule.id);
    const isCurrentlyEnabled = settings.enabledRules[rule.id] !== false; // default true
    
    const ruleLog: SystemLog = {
      id: Math.random().toString(36).substring(7),
      timestamp: new Date().toISOString(),
      level: 'info',
      module: 'Settings',
      message: `${isCurrentlyEnabled ? 'Disabled' : 'Enabled'} offline rule: "${rule.name}"`,
    };
    addLogs([ruleLog]);
  };

  // Rule examples to make it look highly professional
  const ruleExamples: { [ruleId: string]: { bad: string; good: string } } = {
    'subject-verb-agreement': { bad: 'They goes to the office.', good: 'They go to the office.' },
    'articles': { bad: 'I bought a apple.', good: 'I bought an apple.' },
    'capitalization': { bad: 'we live in london.', good: 'We live in London.' },
    'sentence-capitalization': { bad: 'this is fine. another test.', good: 'This is fine. Another test.' },
    'duplicate-spaces': { bad: 'This  has  multiple  spaces.', good: 'This has multiple spaces.' },
    'repeated-words': { bad: 'Is it the the correct word?', good: 'Is it the correct word?' },
    'basic-punctuation': { bad: 'hello ,world', good: 'hello, world' },
    'common-spelling': { bad: 'He recieved the package.', good: 'He received the package.' },
    'whitespace-cleanup': { bad: 'End of sentence.    ', good: 'End of sentence.' },
  };

  return (
    <div id="rules-manager-container" className={`flex-1 flex flex-col min-h-0 overflow-y-auto p-4 md:p-6 transition-colors duration-200 ${
      isDark ? 'bg-[#0F1115]' : 'bg-[#fafafc]'
    }`}>
      
      {/* View Header */}
      <div className="mb-6">
        <h2 className={`text-base font-semibold flex items-center gap-2 ${isDark ? 'text-[#E0E0E0]' : 'text-slate-900'}`}>
          <Sliders className="w-4 h-4 text-[#4CAF50]" />
          <span>RuleManager Configurator</span>
        </h2>
        <p className="text-[11px] text-[#8E9299] font-medium">
          Toggle individual rules or extend behavior. New rules can be hot-plugged in independent files.
        </p>
      </div>

      {/* Grid of Rules */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 mb-6">
        {INITIAL_RULES.map((rule) => {
          const isEnabled = settings.enabledRules[rule.id] !== false; // default true
          const example = ruleExamples[rule.id];
          
          return (
            <div
              key={rule.id}
              id={`rule-item-${rule.id}`}
              className={`p-4 rounded-xl border transition-all duration-150 flex flex-col justify-between ${
                isEnabled
                  ? isDark
                    ? 'bg-[#1A1C21] border-[#2A2D35]'
                    : 'bg-white border-slate-200 shadow-sm'
                  : isDark
                    ? 'bg-[#1C1F26] border-[#2A2D35]/60 opacity-60'
                    : 'bg-slate-100/50 border-slate-200 opacity-60'
              }`}
            >
              <div>
                {/* Name & Toggle */}
                <div className="flex items-start justify-between gap-4 mb-2">
                  <div>
                    <h3 className={`text-xs font-bold flex items-center gap-2 ${isDark ? 'text-[#E0E0E0]' : 'text-slate-800'}`}>
                      <span>{rule.name}</span>
                      <span className={`px-1.5 py-0.25 text-[9px] rounded font-bold uppercase ${
                        rule.category === 'grammar'
                          ? 'bg-purple-950/40 text-purple-400 border border-purple-500/15'
                          : rule.category === 'spelling'
                            ? 'bg-rose-950/40 text-rose-400 border border-rose-500/15'
                            : rule.category === 'punctuation'
                              ? 'bg-blue-950/40 text-blue-400 border border-blue-500/15'
                              : 'bg-amber-950/40 text-amber-400 border border-amber-500/15'
                      }`}>
                        {rule.category}
                      </span>
                    </h3>
                    <p className={`text-[11px] mt-1 leading-relaxed ${isDark ? 'text-[#8E9299]' : 'text-slate-600'}`}>
                      {rule.description}
                    </p>
                  </div>

                  {/* iOS Style Custom Toggle Switch */}
                  <button
                    id={`rule-toggle-switch-${rule.id}`}
                    onClick={() => handleToggle(rule)}
                    className={`relative inline-flex h-5 w-9 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 focus:outline-none ${
                      isEnabled ? 'bg-[#2D6A4F]' : 'bg-slate-700'
                    }`}
                  >
                    <span
                      className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                        isEnabled ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    />
                  </button>
                </div>

                {/* Example box */}
                {example && (
                  <div className={`mt-3 p-2.5 rounded-lg text-[11px] font-mono space-y-1.5 border ${
                    isDark ? 'bg-[#12141A] border-[#2A2D35]' : 'bg-slate-100 border-slate-200'
                  }`}>
                    <div className="flex items-start gap-1">
                      <span className="text-rose-500 font-bold">Incorrect:</span>
                      <span className="text-slate-500 line-through">{example.bad}</span>
                    </div>
                    <div className="flex items-start gap-1">
                      <span className="text-[#4CAF50] font-bold">Corrected:</span>
                      <span className={isDark ? 'text-slate-300 font-semibold' : 'text-slate-800 font-semibold'}>
                        {example.good}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Technical Details */}
              <div className="border-t border-[#2A2D35] pt-3 mt-3 flex items-center justify-between text-[10px] text-[#8E9299]">
                <span className="flex items-center gap-1">
                  <Code className="w-3.5 h-3.5 text-[#8E9299]" />
                  <span>Module: <code className="font-mono text-[#4CAF50] bg-[#1C1F26] border border-[#2A2D35] px-1 py-0.25 rounded">{rule.id}.ts</code></span>
                </span>
                <span>Type: Rule-Based Matcher</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Strategy and Architecture Documentation Accordion */}
      <div className={`p-4 rounded-xl border ${
        isDark ? 'bg-[#1C1F26] border-[#2A2D35]' : 'bg-slate-100/50 border-slate-200'
      }`}>
        <h4 className={`text-xs font-bold flex items-center gap-2 mb-3 ${isDark ? 'text-[#E0E0E0]' : 'text-slate-800'}`}>
          <ShieldCheck className="w-4 h-4 text-[#4CAF50]" />
          <span>Extensible Plugin Architecture</span>
        </h4>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-[11px] leading-relaxed text-[#8E9299]">
          <div className="space-y-1">
            <h5 className={`font-semibold ${isDark ? 'text-[#E0E0E0]' : 'text-slate-700'}`}>1. Strategy Pattern</h5>
            <p>Each rule behaves as an independent strategy implementer matching specific syntax structures without coupling to others.</p>
          </div>
          <div className="space-y-1">
            <h5 className={`font-semibold ${isDark ? 'text-[#E0E0E0]' : 'text-slate-700'}`}>2. High Performance</h5>
            <p>Rules compile as native subroutines in local thread execution queues, keeping individual checks underneath 5ms and aggregate loops under 100ms.</p>
          </div>
          <div className="space-y-1">
            <h5 className={`font-semibold ${isDark ? 'text-[#E0E0E0]' : 'text-slate-700'}`}>3. Adding New Rules</h5>
            <p>Developers hot-plug additions using standard typescript exports without modifying core index loops or tokenizer pipelines.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
