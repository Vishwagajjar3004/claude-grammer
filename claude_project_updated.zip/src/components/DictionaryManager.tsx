import React, { useState } from 'react';
import { 
  BookOpen, 
  Trash2, 
  Plus, 
  Search, 
  ShieldAlert, 
  FolderPlus,
  HelpCircle,
  FileSpreadsheet,
  CheckCircle,
  Terminal
} from 'lucide-react';
import { AppSettings, DictionaryItem, SystemLog } from '../types';

interface DictionaryManagerProps {
  settings: AppSettings;
  customDict: string[];
  addToCustomDict: (word: string) => void;
  removeFromCustomDict: (word: string) => void;
  ignoredWords: string[];
  addToIgnoredWords: (word: string) => void;
  removeFromIgnoredWords: (word: string) => void;
  addLogs: (newLogs: SystemLog[]) => void;
}

export default function DictionaryManager({
  settings,
  customDict,
  addToCustomDict,
  removeFromCustomDict,
  ignoredWords,
  addToIgnoredWords,
  removeFromIgnoredWords,
  addLogs,
}: DictionaryManagerProps) {
  const [newDictWord, setNewDictWord] = useState('');
  const [newIgnoreWord, setNewIgnoreWord] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const isDark = settings.theme === 'dark';

  const handleAddDict = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanWord = newDictWord.trim();
    if (!cleanWord) return;
    
    if (customDict.some(w => w.toLowerCase() === cleanWord.toLowerCase())) {
      alert(`"${cleanWord}" is already present in your custom dictionary.`);
      return;
    }

    addToCustomDict(cleanWord);
    setNewDictWord('');

    const log: SystemLog = {
      id: Math.random().toString(36).substring(7),
      timestamp: new Date().toISOString(),
      level: 'info',
      module: 'Database',
      message: `INSERT INTO custom_dictionary (word) VALUES ('${cleanWord}'); -- Query executed successfully.`,
    };
    addLogs([log]);
  };

  const handleAddIgnore = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanWord = newIgnoreWord.trim();
    if (!cleanWord) return;

    if (ignoredWords.some(w => w.toLowerCase() === cleanWord.toLowerCase())) {
      alert(`"${cleanWord}" is already present in your ignore list.`);
      return;
    }

    addToIgnoredWords(cleanWord);
    setNewIgnoreWord('');

    const log: SystemLog = {
      id: Math.random().toString(36).substring(7),
      timestamp: new Date().toISOString(),
      level: 'info',
      module: 'Database',
      message: `INSERT INTO ignored_words (word) VALUES ('${cleanWord}'); -- Query executed successfully.`,
    };
    addLogs([log]);
  };

  const handleRemoveDict = (word: string) => {
    removeFromCustomDict(word);
    
    const log: SystemLog = {
      id: Math.random().toString(36).substring(7),
      timestamp: new Date().toISOString(),
      level: 'info',
      module: 'Database',
      message: `DELETE FROM custom_dictionary WHERE word = '${word}'; -- Row dropped.`,
    };
    addLogs([log]);
  };

  const handleRemoveIgnore = (word: string) => {
    removeFromIgnoredWords(word);
    
    const log: SystemLog = {
      id: Math.random().toString(36).substring(7),
      timestamp: new Date().toISOString(),
      level: 'info',
      module: 'Database',
      message: `DELETE FROM ignored_words WHERE word = '${word}'; -- Row dropped.`,
    };
    addLogs([log]);
  };

  // Filter lists based on search
  const filteredDict = customDict.filter(w => w.toLowerCase().includes(searchQuery.toLowerCase()));
  const filteredIgnore = ignoredWords.filter(w => w.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div id="dictionary-manager-container" className={`flex-1 flex flex-col min-h-0 overflow-y-auto p-4 md:p-6 transition-colors duration-200 ${
      isDark ? 'bg-[#0F1115]' : 'bg-[#fafafc]'
    }`}>
      
      {/* Header */}
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className={`text-base font-semibold flex items-center gap-2 ${isDark ? 'text-[#E0E0E0]' : 'text-slate-900'}`}>
            <BookOpen className="w-4 h-4 text-[#4CAF50]" />
            <span>Local Dictionaries & Vocabulary</span>
          </h2>
          <p className="text-[11px] text-[#8E9299] font-medium">
            Teach the spelling engine custom words, acronyms, and names that should not be flagged.
          </p>
        </div>

        {/* Global Filter Bar */}
        <div className="relative w-full sm:w-64">
          <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-[#8E9299]" />
          <input
            id="dictionary-search-input"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search words..."
            className={`w-full pl-8 pr-3 py-1.5 rounded-lg border text-xs focus:outline-none focus:ring-1 focus:ring-[#2D6A4F]/50 ${
              isDark 
                ? 'bg-[#1C1F26] border-[#2A2D35] text-[#E0E0E0] placeholder-[#8E9299]/50' 
                : 'bg-white border-slate-300 text-slate-800 placeholder-slate-400'
            }`}
          />
        </div>
      </div>

      {/* Two Columns: Custom Dictionary vs Ignored List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        
        {/* COLUMN 1: Custom Dictionary */}
        <div className={`p-4 rounded-xl border flex flex-col min-h-[300px] ${
          isDark ? 'bg-[#1A1C21] border-[#2A2D35]' : 'bg-white border-slate-200 shadow-sm'
        }`}>
          <div className="flex items-center justify-between mb-4 border-b pb-2 border-[#2A2D35]">
            <div>
              <h3 className={`text-xs font-bold ${isDark ? 'text-[#E0E0E0]' : 'text-slate-800'}`}>
                Custom Dictionary (SQLite)
              </h3>
              <p className="text-[10px] text-[#8E9299] mt-0.5">Persisted custom words marked correct.</p>
            </div>
            <span className="text-[10px] bg-[#2D6A4F]/20 text-[#4CAF50] border border-[#2D6A4F]/30 px-2 py-0.5 rounded font-mono font-bold">
              {customDict.length} Words
            </span>
          </div>

          {/* Quick Input Form */}
          <form onSubmit={handleAddDict} className="flex gap-2 mb-4">
            <input
              id="new-dict-word-input"
              type="text"
              value={newDictWord}
              onChange={(e) => setNewDictWord(e.target.value)}
              placeholder="e.g. Astro, Antigravity, React19"
              className={`flex-1 px-3 py-1.5 rounded-lg border text-xs focus:outline-none focus:ring-1 focus:ring-[#2D6A4F]/50 ${
                isDark 
                  ? 'bg-[#0F1115] border-[#2A2D35] text-[#E0E0E0] placeholder-[#8E9299]/50' 
                  : 'bg-slate-50 border-slate-300 text-slate-800 placeholder-slate-400'
              }`}
            />
            <button
              id="add-dict-word-btn"
              type="submit"
              className="px-3 py-1.5 bg-[#2D6A4F] hover:bg-[#388E3C] text-white font-bold text-xs rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add</span>
            </button>
          </form>

          {/* Lists */}
          <div className="flex-1 overflow-y-auto max-h-64 space-y-1">
            {filteredDict.length === 0 ? (
              <div className="text-center py-8 text-[#8E9299] text-[11px] italic">
                {searchQuery ? 'No matching custom words.' : 'Dictionary is empty. Add your first word!'}
              </div>
            ) : (
              filteredDict.map(word => (
                <div
                  key={word}
                  id={`dict-word-${word}`}
                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs ${
                    isDark ? 'hover:bg-[#1C1F26] text-[#E0E0E0]' : 'hover:bg-slate-50 text-slate-800'
                  }`}
                >
                  <span className="font-medium font-mono">{word}</span>
                  <button
                    id={`remove-dict-word-${word}`}
                    onClick={() => handleRemoveDict(word)}
                    className="p-1 hover:bg-rose-500/15 rounded text-slate-500 hover:text-rose-500 transition-colors cursor-pointer"
                    title="Remove word from local database"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        {/* COLUMN 2: Ignored Words List */}
        <div className={`p-4 rounded-xl border flex flex-col min-h-[300px] ${
          isDark ? 'bg-[#1A1C21] border-[#2A2D35]' : 'bg-white border-slate-200 shadow-sm'
        }`}>
          <div className="flex items-center justify-between mb-4 border-b pb-2 border-[#2A2D35]">
            <div>
              <h3 className={`text-xs font-bold ${isDark ? 'text-[#E0E0E0]' : 'text-slate-800'}`}>
                Session Ignore List
              </h3>
              <p className="text-[10px] text-[#8E9299] mt-0.5">Words temporarily skipped during checks.</p>
            </div>
            <span className="text-[10px] bg-[#2D6A4F]/20 text-[#4CAF50] border border-[#2D6A4F]/30 px-2 py-0.5 rounded font-mono font-bold">
              {ignoredWords.length} Words
            </span>
          </div>

          {/* Quick Input Form */}
          <form onSubmit={handleAddIgnore} className="flex gap-2 mb-4">
            <input
              id="new-ignore-word-input"
              type="text"
              value={newIgnoreWord}
              onChange={(e) => setNewIgnoreWord(e.target.value)}
              placeholder="e.g. localhost, CXX, devDependencies"
              className={`flex-1 px-3 py-1.5 rounded-lg border text-xs focus:outline-none focus:ring-1 focus:ring-[#2D6A4F]/50 ${
                isDark 
                  ? 'bg-[#0F1115] border-[#2A2D35] text-[#E0E0E0] placeholder-[#8E9299]/50' 
                  : 'bg-slate-50 border-slate-300 text-slate-800 placeholder-slate-400'
              }`}
            />
            <button
              id="add-ignore-word-btn"
              type="submit"
              className="px-3 py-1.5 bg-[#2D6A4F] hover:bg-[#388E3C] text-white font-bold text-xs rounded-lg flex items-center gap-1 cursor-pointer transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add</span>
            </button>
          </form>

          {/* Lists */}
          <div className="flex-1 overflow-y-auto max-h-64 space-y-1">
            {filteredIgnore.length === 0 ? (
              <div className="text-center py-8 text-[#8E9299] text-[11px] italic">
                {searchQuery ? 'No matching ignored words.' : 'Ignore list is empty.'}
              </div>
            ) : (
              filteredIgnore.map(word => (
                <div
                  key={word}
                  id={`ignore-word-${word}`}
                  className={`flex items-center justify-between px-3 py-1.5 rounded-lg text-xs ${
                    isDark ? 'hover:bg-[#1C1F26] text-[#E0E0E0]' : 'hover:bg-slate-50 text-slate-800'
                  }`}
                >
                  <span className="font-medium font-mono">{word}</span>
                  <button
                    id={`remove-ignore-word-${word}`}
                    onClick={() => handleRemoveIgnore(word)}
                    className="p-1 hover:bg-rose-500/15 rounded text-slate-500 hover:text-rose-500 transition-colors cursor-pointer"
                    title="Remove word from ignore list"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

      {/* SQL Under-The-Hood query reference block */}
      <div className={`p-4 rounded-xl border ${
        isDark ? 'bg-[#1C1F26] border-[#2A2D35]' : 'bg-slate-100/50 border-slate-200'
      }`}>
        <h4 className={`text-xs font-bold flex items-center gap-2 mb-2 ${isDark ? 'text-[#E0E0E0]' : 'text-slate-800'}`}>
          <Terminal className="w-4 h-4 text-[#4CAF50]" />
          <span>Local Storage Mechanism</span>
        </h4>
        <p className="text-[11px] text-[#8E9299] leading-normal">
          In production, these custom dictionaries correspond directly to real SQLite entries saved in 
          <code className="mx-1 px-1 py-0.5 rounded bg-[#0F1115] text-[#4CAF50] border border-[#2A2D35] font-mono">~/.config/ga/db.sqlite</code>.
          Any custom additions execute raw transaction safe DML queries against local caches immediately. No text is leaked to external endpoints.
        </p>
      </div>

    </div>
  );
}
