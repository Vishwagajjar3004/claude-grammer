import React, { useState, useEffect, useRef } from 'react';
import { 
  Check, 
  Trash2, 
  Sparkles, 
  Volume2, 
  FileText, 
  AlertCircle, 
  AlertTriangle,
  X,
  RotateCcw, 
  HelpCircle,
  Clock,
  Eye,
  Settings,
  ChevronRight,
  BookOpen,
  Plus,
  Cpu
} from 'lucide-react';
import { AppSettings, Suggestion, SystemLog } from '../types';
import { checkText } from '../grammarEngine';

interface WritingCanvasProps {
  settings: AppSettings;
  updateSetting: <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => void;
  customDict: string[];
  addToCustomDict: (word: string) => void;
  ignoredWords: string[];
  addToIgnoredWords: (word: string) => void;
  logs: SystemLog[];
  addLogs: (newLogs: SystemLog[]) => void;
  incrementStats: (accepted: boolean, category: string) => void;
}

export default function WritingCanvas({
  settings,
  updateSetting,
  customDict,
  addToCustomDict,
  ignoredWords,
  addToIgnoredWords,
  logs,
  addLogs,
  incrementStats,
}: WritingCanvasProps) {
  const [text, setText] = useState<string>(
    'i received a apple yesterday .the the taste was great .we is happy !'
  );
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [selectedSuggestion, setSelectedSuggestion] = useState<Suggestion | null>(null);
  const [analysisTime, setAnalysisTime] = useState<number>(0);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [apiError, setApiError] = useState<{ type: string; message: string } | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const isDark = settings.theme === 'dark';

  // Clear api error if engine mode is changed to offline manually
  useEffect(() => {
    if (settings.engineMode === 'offline') {
      setApiError(null);
    }
  }, [settings.engineMode]);

  // Core Demo Templates
  const templates = [
    {
      title: 'Full Grammar Mix',
      text: 'i received a apple yesterday .the the taste was great .we is happy !',
      description: 'Combines a spelling typo, SVA error, wrong article, repeated words, and sentence capitalization.'
    },
    {
      title: 'Linux Space & Format',
      text: 'this is  a test of the   grammar engine on linux mint .',
      description: 'Contains duplicate spaces, proper capitalization of Linux Mint, and trailing punctuation spaces.'
    },
    {
      title: 'Office Report Errors',
      text: 'every monday i go to work on federal government .they has recieved the files .',
      description: 'Has SVA pronoun error, proper noun capitalization, spelling typo, and spacing issues.'
    }
  ];

  // Analyze text when text changes or rules are toggled
  useEffect(() => {
    setIsAnalyzing(true);
    const debounceTimer = setTimeout(async () => {
      const tStart = performance.now();
      
      if (settings.engineMode === 'dynamic') {
        fetch('/api/check', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ text, customDict, ignoredWords }),
        })
        .then((res) => {
          if (!res.ok) {
            throw new Error(`HTTP ${res.status}`);
          }
          return res.json();
        })
        .then(async (data) => {
          const tEnd = performance.now();
          
          if (data.fallback) {
            // Server encountered Gemini API failure (quota/auth) and requested local check fallback
            const localResult = await checkText(text, customDict, ignoredWords, settings.enabledRules);
            setSuggestions(localResult.suggestions);
            setAnalysisTime(parseFloat((tEnd - tStart).toFixed(1)));
            addLogs(data.logs);
            setApiError({
              type: data.errorType,
              message: data.errorMessage,
            });
            setIsAnalyzing(false);
            
            if (localResult.suggestions.length > 0) {
              setSelectedSuggestion(localResult.suggestions[0]);
            } else {
              setSelectedSuggestion(null);
            }
          } else {
            // Normal successful Gemini proofreading
            setSuggestions(data.suggestions);
            setAnalysisTime(parseFloat((tEnd - tStart).toFixed(1)));
            addLogs(data.logs);
            setApiError(null);
            setIsAnalyzing(false);
            
            if (data.suggestions && data.suggestions.length > 0) {
              setSelectedSuggestion(data.suggestions[0]);
            } else {
              setSelectedSuggestion(null);
            }
          }
        })
        .catch(async (err) => {
          console.warn('Dynamic engine failed. Falling back to offline local engine:', err);
          const result = await checkText(text, customDict, ignoredWords, settings.enabledRules);
          const tEnd = performance.now();
          setSuggestions(result.suggestions);
          setAnalysisTime(parseFloat((tEnd - tStart).toFixed(1)));
          
          setApiError({
            type: 'network',
            message: err.message || String(err),
          });

          const errorLog = {
            id: Math.random().toString(36).substring(7),
            timestamp: new Date().toISOString(),
            level: 'error' as const,
            module: 'GrammarEngine' as const,
            message: `Dynamic AI engine failed (${err.message || err}). Falling back to Offline Rule-Based Matcher.`,
          };
          addLogs([errorLog, ...result.logs]);
          setIsAnalyzing(false);
          
          if (result.suggestions.length > 0) {
            setSelectedSuggestion(result.suggestions[0]);
          } else {
            setSelectedSuggestion(null);
          }
        });
      } else {
        const result = await checkText(text, customDict, ignoredWords, settings.enabledRules);
        const tEnd = performance.now();
        
        setSuggestions(result.suggestions);
        setAnalysisTime(parseFloat((tEnd - tStart).toFixed(1)));
        addLogs(result.logs);
        setIsAnalyzing(false);

        // Auto-focus on the first suggestion if none is selected
        if (result.suggestions.length > 0) {
          setSelectedSuggestion(result.suggestions[0]);
        } else {
          setSelectedSuggestion(null);
        }
      }
    }, settings.popupDelay);

    return () => clearTimeout(debounceTimer);
  }, [text, customDict, ignoredWords, settings.enabledRules, settings.popupDelay, settings.engineMode]);

  // Handle Accept Suggestion
  const handleAccept = (suggestion: Suggestion, replacementOverride?: string) => {
    const replacement = replacementOverride ?? suggestion.suggestedText;
    const updatedText = 
      text.substring(0, suggestion.startIndex) + 
      replacement + 
      text.substring(suggestion.endIndex);

    // Update cursor / selection offsets
    const delta = replacement.length - (suggestion.endIndex - suggestion.startIndex);
    
    setText(updatedText);
    incrementStats(true, suggestion.ruleId);

    // Write log
    const acceptedLog: SystemLog = {
      id: Math.random().toString(36).substring(7),
      timestamp: new Date().toISOString(),
      level: 'info',
      module: 'Popup',
      message: `Accepted suggestion: "${suggestion.originalText}" -> "${replacement}" (Rule: ${suggestion.ruleName})`,
    };
    addLogs([acceptedLog]);

    // Focus textarea
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  // Handle Ignore Suggestion
  const handleIgnore = (suggestion: Suggestion) => {
    addToIgnoredWords(suggestion.originalText);
    incrementStats(false, suggestion.ruleId);

    // Write log
    const ignoredLog: SystemLog = {
      id: Math.random().toString(36).substring(7),
      timestamp: new Date().toISOString(),
      level: 'info',
      module: 'Popup',
      message: `Ignored suggestion for "${suggestion.originalText}" (Rule: ${suggestion.ruleName})`,
    };
    addLogs([ignoredLog]);
  };

  // Add misspelled word to dictionary
  const handleAddToDictionary = (word: string) => {
    addToCustomDict(word);
    
    // Write log
    const dictLog: SystemLog = {
      id: Math.random().toString(36).substring(7),
      timestamp: new Date().toISOString(),
      level: 'info',
      module: 'Database',
      message: `Added "${word}" to custom SQLite dictionary.`,
    };
    addLogs([dictLog]);
  };

  // Quick stats calculations
  const wordCount = text.trim() === '' ? 0 : text.trim().split(/\s+/).length;
  const charCount = text.length;

  return (
    <div id="writing-canvas-container" className="flex-1 flex flex-col md:flex-row min-h-0 bg-[#0F1115]">
      
      {/* LEFT: Writing Area & Controls */}
      <div className={`flex-1 flex flex-col min-h-0 p-4 md:p-6 transition-colors duration-200 ${
        isDark ? 'bg-[#0F1115]' : 'bg-[#fafafc]'
      }`}>
        
        {/* Header / Statistics Indicators */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
          <div>
            <h2 className={`text-base font-semibold flex items-center gap-2 ${isDark ? 'text-[#E0E0E0]' : 'text-slate-900'}`}>
              <FileText className={`w-4 h-4 ${settings.engineMode === 'dynamic' ? 'text-purple-400' : 'text-[#4CAF50]'}`} />
              <span>{settings.engineMode === 'dynamic' ? 'Dynamic AI Writing Workspace' : 'Offline Desktop Editor'}</span>
            </h2>
            <p className="text-[11px] text-[#8E9299] font-medium">
              {settings.engineMode === 'dynamic' 
                ? 'Cloud-backed real-time proofreading powered by Gemini 3.5' 
                : 'Local offline interop mode listening for modifications'}
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs text-[#8E9299]">
            <button
              id="engine-header-toggle"
              onClick={() => {
                const nextMode = settings.engineMode === 'dynamic' ? 'offline' : 'dynamic';
                updateSetting('engineMode', nextMode);
                const modeLog: SystemLog = {
                  id: Math.random().toString(36).substring(7),
                  timestamp: new Date().toISOString(),
                  level: 'info',
                  module: 'Settings',
                  message: `Switched grammar engine to: ${nextMode === 'dynamic' ? 'Dynamic AI (Gemini)' : 'Offline Local'}`,
                };
                addLogs([modeLog]);
              }}
              className={`px-2.5 py-1 rounded-md border flex items-center gap-1.5 font-semibold text-xs cursor-pointer transition-all ${
                settings.engineMode === 'dynamic'
                  ? 'bg-purple-950/40 border-purple-500/40 text-purple-300 hover:bg-purple-950/60 hover:border-purple-500/60'
                  : 'bg-slate-800/40 border-slate-700/50 text-slate-400 hover:bg-slate-800/60 hover:border-slate-700/80'
              }`}
              title="Click to toggle between local offline grammar rules and dynamic Gemini AI modes"
            >
              <Cpu className={`w-3.5 h-3.5 ${settings.engineMode === 'dynamic' ? 'text-purple-400 animate-pulse' : 'text-slate-500'}`} />
              <span>{settings.engineMode === 'dynamic' ? 'AI Dynamic' : 'Local Offline'}</span>
            </button>
            <span className={`px-2.5 py-1 rounded-md border flex items-center gap-1.5 font-medium ${
              isDark ? 'bg-[#1C1F26] border-[#2A2D35]' : 'bg-slate-200/50 border-slate-300/40 text-slate-700'
            }`}>
              <Clock className="w-3.5 h-3.5 text-[#8E9299]" />
              <span>Response: <strong className={analysisTime > 100 ? 'text-amber-400' : 'text-[#4CAF50]'}>{analysisTime}ms</strong></span>
            </span>
            <span className={`px-2.5 py-1 rounded-md border flex items-center gap-1.5 font-mono ${
              isDark ? 'bg-[#1C1F26] border-[#2A2D35]' : 'bg-slate-200/50 border-slate-300/40 text-slate-700'
            }`}>
              {wordCount} Words | {charCount} Chars
            </span>
          </div>
        </div>

        {/* Demo Sentence Presets Bar */}
        <div className={`p-3 rounded-lg border mb-4 flex flex-col sm:flex-row sm:items-center gap-3 transition-colors ${
          isDark ? 'bg-[#1C1F26] border-[#2A2D35]' : 'bg-slate-100 border-slate-200'
        }`}>
          <div className="flex items-center gap-1.5 text-xs font-semibold text-[#4CAF50]">
            <Sparkles className="w-4 h-4" />
            <span>Load Linux Templates:</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {templates.map((tpl, idx) => (
              <button
                key={idx}
                id={`template-btn-${idx}`}
                onClick={() => {
                  setText(tpl.text);
                  const templateLog: SystemLog = {
                    id: Math.random().toString(36).substring(7),
                    timestamp: new Date().toISOString(),
                    level: 'info',
                    module: 'Settings',
                    message: `Loaded template sentence: "${tpl.title}"`,
                  };
                  addLogs([templateLog]);
                }}
                className={`text-[11px] px-2.5 py-1 rounded-md font-medium border cursor-pointer transition-all ${
                  isDark
                    ? 'bg-[#1A1C21] border-[#2A2D35] text-[#8E9299] hover:bg-[#2A2D35] hover:text-[#E0E0E0] hover:border-[#3A3D45]'
                    : 'bg-white border-slate-300/80 text-slate-700 hover:bg-slate-50 hover:text-slate-950 hover:border-slate-400'
                }`}
                title={tpl.description}
              >
                {tpl.title}
              </button>
            ))}
          </div>
        </div>

        {apiError && (
          <div className={`p-3.5 rounded-lg border mb-4 flex gap-3 text-xs items-start relative ${
            isDark 
              ? 'bg-amber-950/20 border-amber-500/30 text-amber-300' 
              : 'bg-amber-50 border-amber-200 text-amber-800 shadow-sm'
          }`}>
            <AlertTriangle className={`w-4 h-4 mt-0.5 flex-shrink-0 ${isDark ? 'text-amber-400' : 'text-amber-600'}`} />
            <div className="flex-1 space-y-1">
              <p className="font-bold flex items-center gap-1.5">
                <span>
                  {apiError.type === 'quota' 
                    ? 'Gemini API Quota Exceeded (429)' 
                    : apiError.type === 'permission'
                      ? 'Gemini API Access Denied (403)'
                      : 'Dynamic AI Engine Warning'}
                </span>
              </p>
              <p className="opacity-90 leading-relaxed text-[11px]">
                {apiError.type === 'quota'
                  ? 'You have temporarily exceeded the free tier rate limit for Gemini 3.5. The editor has automatically fallback-loaded the local offline grammar & spelling rules engine so you can type without interruption.'
                  : apiError.type === 'permission'
                    ? 'Your cloud project or API Key has been denied access to Gemini (403 Permission Denied). The editor is running the high-performance local rules engine to keep your workspace active.'
                    : `The dynamic AI engine encountered an issue: "${apiError.message}". Using local offline rules engine fallback instead.`}
              </p>
              <div className="pt-2 flex flex-wrap gap-2">
                <button
                  onClick={() => {
                    updateSetting('engineMode', 'offline');
                  }}
                  className={`px-2 py-1 rounded font-semibold text-[10px] transition-all cursor-pointer ${
                    isDark 
                      ? 'bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 border border-amber-500/30' 
                      : 'bg-amber-100 text-amber-900 hover:bg-amber-200 border border-amber-300'
                  }`}
                >
                  Switch to Local Offline Mode
                </button>
                <button
                  onClick={() => setApiError(null)}
                  className={`px-2 py-1 rounded font-semibold text-[10px] transition-all cursor-pointer ${
                    isDark 
                      ? 'bg-transparent text-amber-400 hover:bg-amber-500/10' 
                      : 'bg-transparent text-amber-700 hover:bg-slate-200/50'
                  }`}
                >
                  Dismiss
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Actual Rich Editor Section */}
        <div className="flex-1 flex flex-col min-h-0 relative">
          
          {/* Main Textarea */}
          <textarea
            ref={textareaRef}
            id="editor-textarea"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Start typing some text to verify grammar and spelling..."
            className={`w-full flex-1 p-4 md:p-5 rounded-xl border text-sm leading-relaxed focus:outline-none focus:ring-1 focus:ring-[#2D6A4F]/50 resize-none font-sans ${
              isDark
                ? 'bg-[#0F1115] border-[#2A2D35] text-[#E0E0E0] placeholder-[#8E9299]/50'
                : 'bg-white border-slate-200 text-slate-900 placeholder-slate-400 shadow-sm'
            }`}
            style={{
              fontSize: settings.fontSize === 'small' ? '13px' : settings.fontSize === 'large' ? '17px' : '15px'
            }}
          />

          {/* Under-TextArea Help Overlay */}
          <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between text-[11px] text-[#8E9299] pointer-events-none">
            <span>
              {settings.engineMode === 'dynamic' 
                ? (apiError ? 'Analyzing with Local Rules (AI Offline Fallback)' : 'Analyzing with Dynamic Gemini AI') 
                : 'Analyzing offline (SymSpell + RuleManager)'}
            </span>
            <span className={`flex items-center gap-1.5 font-semibold ${
              settings.engineMode === 'dynamic' && !apiError ? 'text-purple-400' : 'text-[#4CAF50]'
            }`}>
              <span className={`w-1.5 h-1.5 rounded-full ${
                settings.engineMode === 'dynamic' && !apiError 
                  ? 'bg-purple-400 shadow-[0_0_6px_#a855f7]' 
                  : 'bg-[#4CAF50]'
              } ${isAnalyzing ? 'animate-ping' : ''}`} />
              {isAnalyzing ? 'Daemon scanning...' : 'System synced'}
            </span>
          </div>
        </div>

        {/* Bottom utility: Prune trailing / Reset */}
        <div className="flex items-center justify-between mt-3 text-xs">
          <button
            id="reset-editor-btn"
            onClick={() => {
              setText('');
              const clearLog: SystemLog = {
                id: Math.random().toString(36).substring(7),
                timestamp: new Date().toISOString(),
                level: 'info',
                module: 'Settings',
                message: 'Cleared writing workspace.',
              };
              addLogs([clearLog]);
            }}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-md border cursor-pointer font-medium ${
              isDark 
                ? 'bg-[#1C1F26] border-[#2A2D35] text-[#8E9299] hover:text-white hover:bg-[#2A2D35]' 
                : 'bg-white border-slate-300 text-slate-600 hover:text-slate-950 hover:bg-slate-100'
            }`}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Canvas</span>
          </button>

          <span className="text-slate-500 font-medium">
            Rule coverage: 9 active categories
          </span>
        </div>
      </div>

      {/* RIGHT: Suggestions & Explanations sidebar */}
      <div className={`w-full md:w-80 border-t md:border-t-0 md:border-l flex flex-col min-h-0 transition-colors duration-200 ${
        isDark ? 'bg-[#12141A] border-[#2A2D35]' : 'bg-[#f4f4f7] border-slate-200'
      }`}>
        <div className={`p-4 border-b flex items-center justify-between ${
          isDark ? 'border-[#2A2D35] bg-[#12141A]' : 'border-slate-200 bg-slate-200/30'
        }`}>
          <div className="flex items-center gap-2">
            <span className={`w-5 h-5 rounded-full flex items-center justify-center font-bold text-xs ${
              suggestions.length > 0 ? 'bg-rose-500 text-white' : 'bg-[#2D6A4F] text-white'
            }`}>
              {suggestions.length}
            </span>
            <span className={`text-xs font-bold ${isDark ? 'text-[#E0E0E0]' : 'text-slate-800'}`}>
              Writing Suggestions
            </span>
          </div>

          <span className="text-[10px] text-[#8E9299] font-mono font-bold uppercase">
            Milestone 2 Popup
          </span>
        </div>

        {/* Suggestion Cards Container */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5 min-h-0">
          {suggestions.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-4">
              <div className="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mb-3">
                <Check className="w-6 h-6 text-emerald-400" />
              </div>
              <h3 className={`text-xs font-semibold ${isDark ? 'text-slate-200' : 'text-slate-800'}`}>
                Excellent Writing!
              </h3>
              <p className="text-[11px] text-slate-500 mt-1 max-w-[200px]">
                No grammar, spelling, or capitalization alerts found in the current buffer.
              </p>
            </div>
          ) : (
            suggestions.map((sug) => {
              const isSelected = selectedSuggestion?.id === sug.id;
              return (
                <div
                  key={sug.id}
                  id={`suggestion-card-${sug.id}`}
                  onClick={() => setSelectedSuggestion(sug)}
                  className={`p-3.5 rounded-xl border transition-all duration-200 text-xs cursor-pointer ${
                    isSelected
                      ? isDark
                        ? 'bg-[#1A1C21] border-[#3A3D45] shadow-2xl shadow-black/40'
                        : 'bg-white border-emerald-500 shadow-md shadow-slate-200'
                      : isDark
                        ? 'bg-[#1C1F26] border-[#2A2D35] hover:border-[#3A3D45]'
                        : 'bg-white border-slate-200 hover:border-slate-350'
                  }`}
                >
                  {/* Category Badge & Severity */}
                  <div className="flex items-start justify-between mb-3">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                      sug.type === 'error'
                        ? 'bg-rose-950/40 text-rose-400 border border-rose-500/15'
                        : sug.type === 'warning'
                          ? 'bg-amber-950/40 text-amber-400 border border-amber-500/15'
                          : 'bg-blue-950/40 text-blue-400 border border-blue-500/15'
                    }`}>
                      {sug.ruleName}
                    </span>

                    <span className="text-[10px] text-[#8E9299] font-semibold">
                      Offset: {sug.startIndex}
                    </span>
                  </div>

                  {/* Original vs Suggestion */}
                  <div className="space-y-1.5 mb-3">
                    <div className="flex items-center gap-1.5">
                      <span className="text-[#8E9299] text-[11px] font-medium w-14">Instead of:</span>
                      <span className="line-through text-rose-500 bg-rose-500/5 px-1.5 py-0.25 rounded font-medium">
                        {sug.originalText}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[#8E9299] text-[11px] font-medium w-14">Suggested:</span>
                      <span className="text-[#4CAF50] bg-[#2D6A4F]/10 px-1.5 py-0.25 rounded font-bold">
                        {sug.suggestedText || '∅ (Remove)'}
                      </span>
                    </div>
                    {sug.alternatives && sug.alternatives.length > 0 && (
                      <div className="flex items-start gap-2">
                        <span className="text-[#8E9299] text-[11px] font-medium w-14 pt-0.5">Also try:</span>
                        <div className="flex flex-wrap gap-1.5">
                          {sug.alternatives.map((alt) => (
                            <button
                              key={alt}
                              onClick={(e) => {
                                e.stopPropagation();
                                handleAccept(sug, alt);
                              }}
                              className={`px-1.5 py-0.5 rounded text-[11px] font-medium cursor-pointer transition-colors border ${
                                isDark
                                  ? 'border-[#3A3D45] text-[#C9CCD1] hover:bg-[#2A2D35]'
                                  : 'border-slate-300 text-slate-600 hover:bg-slate-100'
                              }`}
                              title={`Use "${alt}" instead`}
                            >
                              {alt}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Details / Explanation */}
                  <p className={`text-[11px] mb-3 leading-relaxed ${isDark ? 'text-[#8E9299]' : 'text-slate-600'}`}>
                    {sug.explanation}
                  </p>

                  {/* Actions buttons */}
                  {isSelected && (
                    <div className="flex items-center justify-end gap-2 border-t pt-3 mt-1 border-[#2A2D35]">
                      <button
                        id={`ignore-btn-${sug.id}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleIgnore(sug);
                        }}
                        className={`px-2.5 py-1.5 rounded-md text-[11px] font-medium cursor-pointer transition-colors ${
                          isDark
                            ? 'bg-[#2A2D35] hover:bg-[#3A3D45] text-white'
                            : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                        }`}
                        title="Add this exact text to ignored words"
                      >
                        Ignore
                      </button>

                      {sug.ruleId === 'common-spelling' && (
                        <button
                          id={`add-dict-btn-${sug.id}`}
                          onClick={(e) => {
                            e.stopPropagation();
                            handleAddToDictionary(sug.originalText);
                          }}
                          className={`px-2.5 py-1.5 rounded-md text-[11px] font-medium cursor-pointer transition-colors ${
                            isDark
                              ? 'bg-[#2A2D35] hover:bg-[#3A3D45] text-white'
                              : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                          }`}
                          title="Save to local database dictionary"
                        >
                          + Dict
                        </button>
                      )}

                      <button
                        id={`accept-btn-${sug.id}`}
                        onClick={(e) => {
                          e.stopPropagation();
                          handleAccept(sug);
                        }}
                        className="px-3 py-1.5 rounded-md bg-[#2D6A4F] hover:bg-[#388E3C] text-white font-bold text-[11px] flex items-center gap-1 cursor-pointer transition-colors"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>Accept</span>
                      </button>
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Selected Suggestion Helper Box */}
        {selectedSuggestion && (
          <div className={`p-4 border-t space-y-2 ${
            isDark ? 'bg-[#12141A] border-[#2A2D35]' : 'bg-slate-200/20 border-slate-200'
          }`}>
            <h4 className={`text-[11px] font-bold uppercase tracking-wide flex items-center gap-1.5 ${
              isDark ? 'text-[#E0E0E0]' : 'text-slate-700'
            }`}>
              <AlertCircle className="w-3.5 h-3.5 text-[#4CAF50]" />
              <span>Offline Rule Meta:</span>
            </h4>
            <div className="text-[10px] text-[#8E9299] leading-normal space-y-1">
              <div>Rule ID: <code className="font-mono bg-[#1A1C21] px-1 py-0.25 border border-[#2A2D35] rounded text-[#4CAF50]">{selectedSuggestion.ruleId}</code></div>
              <div>Scope: RuleManager offline execution module</div>
              <div className="italic text-[9.5px]">All processing matches standard pattern logic locally. No telemetries active.</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
