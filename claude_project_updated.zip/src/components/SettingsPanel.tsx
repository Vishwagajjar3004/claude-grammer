import React from 'react';
import { 
  Sliders, 
  Settings, 
  Moon, 
  Sun, 
  HelpCircle, 
  Keyboard, 
  ToggleLeft, 
  Power, 
  Cpu, 
  Info,
  CheckCircle,
  FileSpreadsheet,
  Sparkles
} from 'lucide-react';
import { AppSettings, SystemLog } from '../types';

interface SettingsPanelProps {
  settings: AppSettings;
  updateSetting: <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => void;
  addLogs: (newLogs: SystemLog[]) => void;
}

export default function SettingsPanel({
  settings,
  updateSetting,
  addLogs,
}: SettingsPanelProps) {
  const isDark = settings.theme === 'dark';

  const handleToggleAutoCorrect = () => {
    const newValue = !settings.autoCorrection;
    updateSetting('autoCorrection', newValue);
    
    const log: SystemLog = {
      id: Math.random().toString(36).substring(7),
      timestamp: new Date().toISOString(),
      level: 'info',
      module: 'Settings',
      message: `UPDATE settings SET auto_correction = ${newValue ? '1' : '0'}; -- Hotkeys & auto-correction values updated.`,
    };
    addLogs([log]);
  };

  const handleToggleStartup = () => {
    const newValue = !settings.launchOnStartup;
    updateSetting('launchOnStartup', newValue);

    const log: SystemLog = {
      id: Math.random().toString(36).substring(7),
      timestamp: new Date().toISOString(),
      level: 'info',
      module: 'Settings',
      message: `UPDATE settings SET launch_on_startup = ${newValue ? '1' : '0'}; -- System startup config synced.`,
    };
    addLogs([log]);
  };

  const handleDelayChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = parseInt(e.target.value);
    updateSetting('popupDelay', newValue);

    const log: SystemLog = {
      id: Math.random().toString(36).substring(7),
      timestamp: new Date().toISOString(),
      level: 'info',
      module: 'Settings',
      message: `UPDATE settings SET popup_delay = ${newValue}; -- Scaning rate updated to ${newValue}ms.`,
    };
    addLogs([log]);
  };

  const handleThemeChange = (theme: 'dark' | 'light' | 'system') => {
    updateSetting('theme', theme);

    const log: SystemLog = {
      id: Math.random().toString(36).substring(7),
      timestamp: new Date().toISOString(),
      level: 'info',
      module: 'Settings',
      message: `UPDATE settings SET theme = '${theme}'; -- UI visual theme changed.`,
    };
    addLogs([log]);
  };

  return (
    <div id="settings-panel-container" className={`flex-1 flex flex-col min-h-0 overflow-y-auto p-4 md:p-6 transition-colors duration-200 ${
      isDark ? 'bg-[#0F1115]' : 'bg-[#fafafc]'
    }`}>
      
      {/* Header */}
      <div className="mb-6">
        <h2 className={`text-base font-semibold flex items-center gap-2 ${isDark ? 'text-[#E0E0E0]' : 'text-slate-900'}`}>
          <Settings className="w-4 h-4 text-[#4CAF50]" />
          <span>Application Preferences & Settings</span>
        </h2>
        <p className="text-[11px] text-[#8E9299] font-medium">
          Configure offline background parameters, system hotkeys, and desktop-first Fluent specifications.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        
        {/* PANEL SECTION A: Performance & Theme */}
        <div className={`p-5 rounded-xl border space-y-5 ${
          isDark ? 'bg-[#1A1C21] border-[#2A2D35]' : 'bg-white border-slate-200 shadow-sm'
        }`}>
          <h3 className={`text-xs font-bold border-b pb-2 flex items-center gap-1.5 ${isDark ? 'text-[#E0E0E0] border-[#2A2D35]' : 'text-slate-850 border-slate-150'}`}>
            <Cpu className="w-4 h-4 text-[#4CAF50]" />
            <span>Engine Performance & Visuals</span>
          </h3>

          {/* Grammar Engine Selection */}
          <div className="space-y-2">
            <label className="text-[11px] font-bold text-[#8E9299] block flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5 text-purple-400" />
              <span>Grammar Engine Mode</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                id="engine-offline-btn"
                onClick={() => {
                  updateSetting('engineMode', 'offline');
                  addLogs([{
                    id: Math.random().toString(36).substring(7),
                    timestamp: new Date().toISOString(),
                    level: 'info',
                    module: 'Settings',
                    message: "Switched grammar engine to Offline Local Rule-Based Mode."
                  }]);
                }}
                className={`px-3 py-2 rounded-lg border text-xs font-semibold flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
                  settings.engineMode === 'offline'
                    ? 'bg-[#2D6A4F] text-white border-[#2D6A4F]'
                    : isDark
                      ? 'bg-[#1C1F26] border-[#2A2D35] text-[#8E9299] hover:bg-[#2A2D35]'
                      : 'bg-slate-50 border-slate-200 text-slate-650 hover:bg-slate-100'
                }`}
              >
                <span className="font-bold">Offline Local</span>
                <span className="text-[9px] opacity-75">Rules + SymSpell</span>
              </button>
              
              <button
                id="engine-dynamic-btn"
                onClick={() => {
                  updateSetting('engineMode', 'dynamic');
                  addLogs([{
                    id: Math.random().toString(36).substring(7),
                    timestamp: new Date().toISOString(),
                    level: 'info',
                    module: 'Settings',
                    message: "Switched grammar engine to Dynamic AI (Gemini Auto-tuning) Mode."
                  }]);
                }}
                className={`px-3 py-2 rounded-lg border text-xs font-semibold flex flex-col items-center justify-center gap-1 cursor-pointer transition-all ${
                  settings.engineMode === 'dynamic'
                    ? 'bg-purple-950/60 text-purple-200 border-purple-500/40'
                    : isDark
                      ? 'bg-[#1C1F26] border-[#2A2D35] text-[#8E9299] hover:bg-[#2A2D35]'
                      : 'bg-slate-50 border-slate-200 text-slate-650 hover:bg-slate-100'
                }`}
              >
                <span className="font-bold flex items-center gap-1">
                  <span>Dynamic AI</span>
                  <Sparkles className="w-3 h-3 text-amber-300 animate-pulse" />
                </span>
                <span className="text-[9px] opacity-75">Gemini AI Engine</span>
              </button>
            </div>
          </div>

          {/* Theme Option */}
          <div className="space-y-2">
            <label className="text-[11px] font-bold text-[#8E9299] block">Visual Theme</label>
            <div className="grid grid-cols-3 gap-2">
              {(['dark', 'light'] as const).map(th => (
                <button
                  key={th}
                  id={`theme-btn-${th}`}
                  onClick={() => handleThemeChange(th)}
                  className={`px-3 py-2 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer transition-all ${
                    settings.theme === th
                      ? 'bg-[#2D6A4F] text-white border-[#2D6A4F]'
                      : isDark
                        ? 'bg-[#1C1F26] border-[#2A2D35] text-[#8E9299] hover:bg-[#2A2D35]'
                        : 'bg-slate-50 border-slate-200 text-slate-650 hover:bg-slate-100'
                  }`}
                >
                  {th === 'dark' ? <Moon className="w-3.5 h-3.5" /> : <Sun className="w-3.5 h-3.5" />}
                  <span className="capitalize">{th}</span>
                </button>
              ))}
              <button
                id="theme-btn-system"
                onClick={() => handleThemeChange('system')}
                className={`px-3 py-2 rounded-lg border text-xs font-semibold flex items-center justify-center gap-2 cursor-pointer transition-all ${
                  settings.theme === 'system'
                    ? 'bg-[#2D6A4F] text-white border-[#2D6A4F]'
                    : isDark
                      ? 'bg-[#1C1F26] border-[#2A2D35] text-[#8E9299] hover:bg-[#2A2D35]'
                      : 'bg-slate-50 border-slate-200 text-slate-650 hover:bg-slate-100'
                }`}
              >
                <span>💻 System</span>
              </button>
            </div>
          </div>

          {/* Popup scanning delay */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-[11px] font-bold text-[#8E9299]">
              <label>Popup Scanning Delay</label>
              <span className="font-mono text-[#4CAF50]">{settings.popupDelay} ms</span>
            </div>
            <input
              id="popup-delay-range"
              type="range"
              min="0"
              max="1500"
              step="50"
              value={settings.popupDelay}
              onChange={handleDelayChange}
              className="w-full h-1 bg-[#2A2D35] rounded-lg appearance-none cursor-pointer accent-[#4CAF50]"
            />
            <div className="flex justify-between text-[10px] text-[#8E9299]">
              <span>Instant (0ms)</span>
              <span>Debounced (Conserve CPU)</span>
            </div>
          </div>

          {/* Popup Card Sizes */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-[#8E9299]">Popup Size</label>
              <select
                id="popup-size-select"
                value={settings.popupSize}
                onChange={(e) => updateSetting('popupSize', e.target.value as any)}
                className={`w-full p-2 rounded-lg border text-xs focus:outline-none focus:ring-1 focus:ring-[#2D6A4F]/50 ${
                  isDark ? 'bg-[#0F1115] border-[#2A2D35] text-[#E0E0E0]' : 'bg-slate-50 border-slate-255 text-slate-750'
                }`}
              >
                <option value="small">Compact (Small)</option>
                <option value="medium">Standard (Medium)</option>
                <option value="large">Spacious (Large)</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-[11px] font-bold text-[#8E9299]">Editor Font Size</label>
              <select
                id="font-size-select"
                value={settings.fontSize}
                onChange={(e) => updateSetting('fontSize', e.target.value as any)}
                className={`w-full p-2 rounded-lg border text-xs focus:outline-none focus:ring-1 focus:ring-[#2D6A4F]/50 ${
                  isDark ? 'bg-[#0F1115] border-[#2A2D35] text-[#E0E0E0]' : 'bg-slate-50 border-slate-255 text-slate-750'
                }`}
              >
                <option value="small">Compact (13px)</option>
                <option value="medium">Standard (15px)</option>
                <option value="large">Generous (17px)</option>
              </select>
            </div>
          </div>
        </div>

        {/* PANEL SECTION B: Interop & Hotkeys */}
        <div className={`p-5 rounded-xl border space-y-5 ${
          isDark ? 'bg-[#1A1C21] border-[#2A2D35]' : 'bg-white border-slate-200 shadow-sm'
        }`}>
          <h3 className={`text-xs font-bold border-b pb-2 flex items-center gap-1.5 ${isDark ? 'text-[#E0E0E0] border-[#2A2D35]' : 'text-slate-850 border-slate-150'}`}>
            <Keyboard className="w-4 h-4 text-[#4CAF50]" />
            <span>Wayland Interop & System Hotkeys</span>
          </h3>

          {/* Autocorrection Toggle */}
          <div className="flex items-center justify-between">
            <div>
              <label className={`text-xs font-bold block ${isDark ? 'text-[#E0E0E0]' : 'text-slate-800'}`}>Auto-Correction</label>
              <span className="text-[10px] text-[#8E9299]">Correct obvious repeated words and spaces on save</span>
            </div>
            <button
              id="autocorrect-toggle-btn"
              onClick={handleToggleAutoCorrect}
              className={`relative inline-flex h-5 w-9 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 focus:outline-none ${
                settings.autoCorrection ? 'bg-[#2D6A4F]' : 'bg-slate-700'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                  settings.autoCorrection ? 'translate-x-4' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Launch on Startup Toggle */}
          <div className="flex items-center justify-between">
            <div>
              <label className={`text-xs font-bold block ${isDark ? 'text-[#E0E0E0]' : 'text-slate-800'}`}>Linux System Autostart</label>
              <span className="text-[10px] text-[#8E9299]">Create systemd service file for auto startup</span>
            </div>
            <button
              id="startup-toggle-btn"
              onClick={handleToggleStartup}
              className={`relative inline-flex h-5 w-9 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 focus:outline-none ${
                settings.launchOnStartup ? 'bg-[#2D6A4F]' : 'bg-slate-700'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                  settings.launchOnStartup ? 'translate-x-4' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Key Mappings */}
          <div className="space-y-3.5">
            <label className="text-[11px] font-bold text-[#8E9299] block">Keyboard Hotkey Configurations</label>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="text-[10px] font-semibold text-[#8E9299]">Accept Correction</label>
                <input
                  id="hotkey-accept-input"
                  type="text"
                  value={settings.hotkeyAccept}
                  onChange={(e) => updateSetting('hotkeyAccept', e.target.value)}
                  className={`w-full p-2 rounded-lg border text-xs text-center font-mono focus:outline-none focus:ring-1 focus:ring-[#2D6A4F]/50 ${
                    isDark ? 'bg-[#0F1115] border-[#2A2D35] text-[#E0E0E0]' : 'bg-slate-50 border-slate-255 text-slate-800'
                  }`}
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-semibold text-[#8E9299]">Ignore suggestion</label>
                <input
                  id="hotkey-ignore-input"
                  type="text"
                  value={settings.hotkeyIgnore}
                  onChange={(e) => updateSetting('hotkeyIgnore', e.target.value)}
                  className={`w-full p-2 rounded-lg border text-xs text-center font-mono focus:outline-none focus:ring-1 focus:ring-[#2D6A4F]/50 ${
                    isDark ? 'bg-[#0F1115] border-[#2A2D35] text-[#E0E0E0]' : 'bg-slate-50 border-slate-255 text-slate-800'
                  }`}
                />
              </div>
            </div>
          </div>
        </div>

      </div>

      {/* About App Info Segment */}
      <div className={`p-5 rounded-xl border flex gap-4 ${
        isDark ? 'bg-[#1C1F26] border-[#2A2D35]' : 'bg-slate-100/50 border-slate-200'
      }`}>
        <Info className="w-5 h-5 text-[#4CAF50] flex-shrink-0 mt-0.5" />
        <div className="space-y-1.5">
          <h4 className={`text-xs font-bold ${isDark ? 'text-[#E0E0E0]' : 'text-slate-800'}`}>
            About Grammar Assistant (Milestone 1, Version 0.1)
          </h4>
          <p className="text-[11px] text-[#8E9299] leading-relaxed">
            Grammar Assistant is a local writing optimizer built for Wayland/X11 Linux desktop installations.
            Unlike standard web integrations, this app establishes secure, zero-cloud IPC socket processes, 
            allowing developers, researchers, and journalists to compose sensitive drafts with pristine confidence.
            MIT License. Crafted in clean, solid architectural patterns.
          </p>
        </div>
      </div>

    </div>
  );
}
