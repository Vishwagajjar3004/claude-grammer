import React, { useState } from 'react';
import { 
  Terminal, 
  Database, 
  Trash2, 
  Play, 
  FileCode, 
  CheckCircle, 
  Info, 
  AlertTriangle, 
  Clock,
  RefreshCw,
  Search,
  Filter
} from 'lucide-react';
import { AppSettings, SystemLog, DictionaryItem } from '../types';

interface DatabaseConsoleProps {
  settings: AppSettings;
  logs: SystemLog[];
  clearLogs: () => void;
  customDict: string[];
  ignoredWords: string[];
  stats: {
    wordsAnalyzed: number;
    correctionsAccepted: number;
    correctionsIgnored: number;
    errorDistribution: { [category: string]: number };
  };
}

export default function DatabaseConsole({
  settings,
  logs,
  clearLogs,
  customDict,
  ignoredWords,
  stats,
}: DatabaseConsoleProps) {
  const [activeSubTab, setActiveSubTab] = useState<'logs' | 'sqlite'>('logs');
  const [logFilter, setLogFilter] = useState<'all' | 'info' | 'warn' | 'error' | 'perf'>('all');
  const [logSearch, setLogSearch] = useState('');
  const [selectedTable, setSelectedTable] = useState<'settings' | 'custom_dict' | 'ignored_words' | 'statistics'>('settings');
  const isDark = settings.theme === 'dark';

  // Filtered Logs
  const filteredLogs = logs.filter(log => {
    const matchesLevel = logFilter === 'all' || log.level === logFilter;
    const matchesSearch = log.message.toLowerCase().includes(logSearch.toLowerCase()) || 
                          log.module.toLowerCase().includes(logSearch.toLowerCase());
    return matchesLevel && matchesSearch;
  });

  return (
    <div id="database-console-container" className={`flex-1 flex flex-col min-h-0 transition-colors duration-200 ${
      isDark ? 'bg-[#0F1115]' : 'bg-[#fafafc]'
    }`}>
      
      {/* Tab Selector Headers */}
      <div className={`px-4 pt-3 flex items-center justify-between border-b ${
        isDark ? 'bg-[#12141A] border-[#2A2D35]' : 'bg-slate-200/20 border-slate-200'
      }`}>
        <div className="flex gap-2">
          <button
            id="subtab-logs-btn"
            onClick={() => setActiveSubTab('logs')}
            className={`px-3 py-2 text-xs font-bold flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
              activeSubTab === 'logs'
                ? 'border-[#4CAF50] text-[#4CAF50]'
                : 'border-transparent text-[#8E9299] hover:text-[#E0E0E0]'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>Stdout System Logs</span>
          </button>
          
          <button
            id="subtab-sqlite-btn"
            onClick={() => setActiveSubTab('sqlite')}
            className={`px-3 py-2 text-xs font-bold flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
              activeSubTab === 'sqlite'
                ? 'border-[#4CAF50] text-[#4CAF50]'
                : 'border-transparent text-[#8E9299] hover:text-[#E0E0E0]'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>SQLite Local Browser</span>
          </button>
        </div>

        <span className="text-[10px] text-[#8E9299] font-medium">
          Offline IPC Link: Active
        </span>
      </div>

      {/* VIEW 1: STDOUT LOGS TERMINAL */}
      {activeSubTab === 'logs' && (
        <div className="flex-1 flex flex-col min-h-0 p-4">
          
          {/* Controls Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
            <div className="flex flex-wrap items-center gap-2">
              {/* Search */}
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-3.5 w-3.5 text-[#8E9299]" />
                <input
                  id="logs-search-input"
                  type="text"
                  value={logSearch}
                  onChange={(e) => setLogSearch(e.target.value)}
                  placeholder="Filter messages..."
                  className={`pl-8 pr-3 py-1 rounded-md border text-[11px] focus:outline-none focus:ring-1 focus:ring-[#2D6A4F]/50 ${
                    isDark 
                      ? 'bg-[#1C1F26] border-[#2A2D35] text-[#E0E0E0] placeholder-[#8E9299]/50' 
                      : 'bg-white border-slate-300 text-slate-800 placeholder-slate-400'
                  }`}
                />
              </div>

              {/* Filter Buttons */}
              <div className="flex rounded-md shadow-sm border border-[#2A2D35]">
                {(['all', 'info', 'perf', 'warn', 'error'] as const).map(lvl => (
                  <button
                    key={lvl}
                    id={`log-filter-btn-${lvl}`}
                    onClick={() => setLogFilter(lvl)}
                    className={`px-2.5 py-1 text-[10px] font-bold uppercase transition-all border-r border-[#2A2D35] last:border-r-0 cursor-pointer ${
                      logFilter === lvl
                        ? 'bg-[#2D6A4F] text-white'
                        : isDark
                          ? 'bg-[#1C1F26] hover:bg-[#2A2D35] text-[#8E9299]'
                          : 'bg-slate-100 hover:bg-slate-250 text-slate-600'
                    }`}
                  >
                    {lvl}
                  </button>
                ))}
              </div>
            </div>

            <button
              id="clear-logs-btn"
              onClick={clearLogs}
              className={`flex items-center gap-1.5 px-3 py-1 text-xs rounded-md border font-medium cursor-pointer transition-all ${
                isDark
                  ? 'bg-[#1C1F26] border-[#2A2D35] text-[#8E9299] hover:bg-[#2A2D35] hover:text-[#E0E0E0]'
                  : 'bg-white border-slate-300 text-slate-600 hover:bg-slate-100 hover:text-slate-950'
              }`}
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Terminal</span>
            </button>
          </div>

          {/* Logs Output Console Screen */}
          <div className="flex-1 bg-[#12141A] rounded-xl p-4 font-mono text-[11px] overflow-y-auto leading-relaxed border border-[#2A2D35] select-text">
            {filteredLogs.length === 0 ? (
              <div className="text-slate-600 italic py-8 text-center">
                -- Terminal is idle. No system logs matched. --
              </div>
            ) : (
              filteredLogs.map(log => {
                let colorClass = 'text-slate-300';
                if (log.level === 'warn') colorClass = 'text-amber-400';
                else if (log.level === 'error') colorClass = 'text-rose-400';
                else if (log.level === 'perf') colorClass = 'text-[#4CAF50] font-medium';

                return (
                  <div key={log.id} className="hover:bg-white/5 py-0.5 px-1 rounded flex items-start gap-3">
                    <span className="text-[#8E9299]/60 select-none">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                    <span className={`font-semibold uppercase select-none w-16 flex-shrink-0 ${
                      log.level === 'info' ? 'text-blue-400' : colorClass
                    }`}>
                      [{log.level}]
                    </span>
                    <span className="text-[#8E9299] select-none w-28 flex-shrink-0">
                      [{log.module}]
                    </span>
                    <span className={`flex-1 ${colorClass}`}>
                      {log.message}
                      {log.durationMs !== undefined && (
                        <span className="text-[#4CAF50] font-semibold ml-2">
                          ({log.durationMs}ms)
                        </span>
                      )}
                    </span>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* VIEW 2: SQLITE BROWSER */}
      {activeSubTab === 'sqlite' && (
        <div className="flex-1 flex flex-col md:flex-row min-h-0">
          
          {/* SQLite Sidebar Tables List */}
          <div className={`w-full md:w-48 border-b md:border-b-0 md:border-r p-4 space-y-2 transition-colors ${
            isDark ? 'border-[#2A2D35] bg-[#12141A]' : 'border-slate-200 bg-slate-100/30'
          }`}>
            <div className="text-[10px] font-bold text-[#8E9299] uppercase tracking-wider mb-2">
              SQLite Schema Tables
            </div>

            {(['settings', 'custom_dict', 'ignored_words', 'statistics'] as const).map(tbl => (
              <button
                key={tbl}
                id={`table-select-btn-${tbl}`}
                onClick={() => setSelectedTable(tbl)}
                className={`w-full text-left px-2.5 py-1.5 rounded text-xs font-semibold flex items-center justify-between transition-colors cursor-pointer ${
                  selectedTable === tbl
                    ? 'bg-[#2D6A4F]/20 text-[#4CAF50] font-bold border-l-2 border-[#4CAF50]'
                    : isDark
                      ? 'hover:bg-[#1C1F26] text-[#8E9299] hover:text-[#E0E0E0]'
                      : 'hover:bg-slate-200 text-slate-600 hover:text-slate-900'
                }`}
              >
                <span>{tbl === 'custom_dict' ? 'custom_dictionary' : tbl}</span>
                <Database className="w-3 h-3 text-[#8E9299]" />
              </button>
            ))}
          </div>

          {/* SQLite Table Contents Visualizer */}
          <div className="flex-1 flex flex-col min-h-0 p-4">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className={`text-xs font-bold ${isDark ? 'text-[#E0E0E0]' : 'text-slate-800'}`}>
                  Table Name: <span className="font-mono text-[#4CAF50]">{selectedTable === 'custom_dict' ? 'custom_dictionary' : selectedTable}</span>
                </h3>
                <p className="text-[10px] text-[#8E9299] mt-0.5">Dumping records from system SQLite connection cache.</p>
              </div>

              <span className="text-[10px] font-mono font-bold bg-[#1C1F26] px-2 py-0.5 border border-[#2A2D35] rounded text-[#8E9299]">
                SQLITE3 ENGINE
              </span>
            </div>

            {/* Table layout wrapper */}
            <div className={`flex-1 overflow-auto border rounded-xl ${
              isDark ? 'bg-[#1A1C21] border-[#2A2D35]' : 'bg-white border-slate-200 shadow-sm'
            }`}>
              {selectedTable === 'settings' && (
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className={`border-b text-[10px] font-bold text-[#8E9299] uppercase tracking-wide ${isDark ? 'border-[#2A2D35] bg-[#12141A]' : 'border-slate-200 bg-slate-50'}`}>
                      <th className="p-3">key</th>
                      <th className="p-3">value</th>
                      <th className="p-3">type</th>
                    </tr>
                  </thead>
                  <tbody className={isDark ? 'text-[#E0E0E0]' : 'text-slate-700'}>
                    <tr className={`border-b ${isDark ? 'border-[#2A2D35]' : 'border-slate-100'}`}>
                      <td className="p-3 font-mono">popup_delay</td>
                      <td className="p-3 font-mono">{settings.popupDelay} ms</td>
                      <td className="p-3 text-[#8E9299]">INTEGER</td>
                    </tr>
                    <tr className={`border-b ${isDark ? 'border-[#2A2D35]' : 'border-slate-100'}`}>
                      <td className="p-3 font-mono">popup_size</td>
                      <td className="p-3 font-mono">{settings.popupSize}</td>
                      <td className="p-3 text-[#8E9299]">TEXT</td>
                    </tr>
                    <tr className={`border-b ${isDark ? 'border-[#2A2D35]' : 'border-slate-100'}`}>
                      <td className="p-3 font-mono">font_size</td>
                      <td className="p-3 font-mono">{settings.fontSize}</td>
                      <td className="p-3 text-[#8E9299]">TEXT</td>
                    </tr>
                    <tr className={`border-b ${isDark ? 'border-[#2A2D35]' : 'border-slate-100'}`}>
                      <td className="p-3 font-mono">auto_correction</td>
                      <td className="p-3 font-mono">{settings.autoCorrection ? '1' : '0'}</td>
                      <td className="p-3 text-[#8E9299]">INTEGER</td>
                    </tr>
                    <tr className={`border-b ${isDark ? 'border-[#2A2D35]' : 'border-slate-100'}`}>
                      <td className="p-3 font-mono">theme</td>
                      <td className="p-3 font-mono">{settings.theme}</td>
                      <td className="p-3 text-[#8E9299]">TEXT</td>
                    </tr>
                    <tr className={`border-b ${isDark ? 'border-[#2A2D35]' : 'border-slate-100'}`}>
                      <td className="p-3 font-mono">hotkey_accept</td>
                      <td className="p-3 font-mono">{settings.hotkeyAccept}</td>
                      <td className="p-3 text-[#8E9299]">TEXT</td>
                    </tr>
                  </tbody>
                </table>
              )}

              {selectedTable === 'custom_dict' && (
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className={`border-b text-[10px] font-bold text-[#8E9299] uppercase tracking-wide ${isDark ? 'border-[#2A2D35] bg-[#12141A]' : 'border-slate-200 bg-slate-50'}`}>
                      <th className="p-3">id</th>
                      <th className="p-3">word</th>
                      <th className="p-3">added_at</th>
                    </tr>
                  </thead>
                  <tbody className={isDark ? 'text-[#E0E0E0]' : 'text-slate-700'}>
                    {customDict.length === 0 ? (
                      <tr>
                        <td colSpan={3} className="p-3 text-center text-[#8E9299] italic">No records found. Table custom_dictionary is empty.</td>
                      </tr>
                    ) : (
                      customDict.map((word, index) => (
                        <tr key={word} className={`border-b ${isDark ? 'border-[#2A2D35]' : 'border-slate-100'}`}>
                          <td className="p-3 font-mono text-[#8E9299]">{index + 1}</td>
                          <td className="p-3 font-semibold font-mono text-[#4CAF50]">{word}</td>
                          <td className="p-3 text-[#8E9299] font-mono">2026-07-05 23:27:52</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              )}

              {selectedTable === 'ignored_words' && (
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className={`border-b text-[10px] font-bold text-[#8E9299] uppercase tracking-wide ${isDark ? 'border-[#2A2D35] bg-[#12141A]' : 'border-slate-200 bg-slate-50'}`}>
                      <th className="p-3">id</th>
                      <th className="p-3">word</th>
                    </tr>
                  </thead>
                  <tbody className={isDark ? 'text-[#E0E0E0]' : 'text-slate-700'}>
                    {ignoredWords.length === 0 ? (
                      <tr>
                        <td colSpan={2} className="p-3 text-center text-[#8E9299] italic">No records found. Table ignored_words is empty.</td>
                      </tr>
                    ) : (
                      ignoredWords.map((word, index) => (
                        <tr key={word} className={`border-b ${isDark ? 'border-[#2A2D35]' : 'border-slate-100'}`}>
                          <td className="p-3 font-mono text-[#8E9299]">{index + 1}</td>
                          <td className="p-3 font-semibold font-mono text-amber-400">{word}</td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              )}

              {selectedTable === 'statistics' && (
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className={`border-b text-[10px] font-bold text-[#8E9299] uppercase tracking-wide ${isDark ? 'border-[#2A2D35] bg-[#12141A]' : 'border-slate-200 bg-slate-50'}`}>
                      <th className="p-3">metric</th>
                      <th className="p-3">value</th>
                    </tr>
                  </thead>
                  <tbody className={isDark ? 'text-[#E0E0E0]' : 'text-slate-700'}>
                    <tr className={`border-b ${isDark ? 'border-[#2A2D35]' : 'border-slate-100'}`}>
                      <td className="p-3 font-mono text-[#8E9299]">words_analyzed</td>
                      <td className="p-3 font-mono font-bold text-[#4CAF50]">{stats.wordsAnalyzed}</td>
                    </tr>
                    <tr className={`border-b ${isDark ? 'border-[#2A2D35]' : 'border-slate-100'}`}>
                      <td className="p-3 font-mono text-[#8E9299]">corrections_accepted</td>
                      <td className="p-3 font-mono font-bold text-[#4CAF50]">{stats.correctionsAccepted}</td>
                    </tr>
                    <tr className={`border-b ${isDark ? 'border-[#2A2D35]' : 'border-slate-100'}`}>
                      <td className="p-3 font-mono text-[#8E9299]">corrections_ignored</td>
                      <td className="p-3 font-mono font-bold text-amber-400">{stats.correctionsIgnored}</td>
                    </tr>
                    <tr className={`border-b ${isDark ? 'border-[#2A2D35]' : 'border-slate-100'}`}>
                      <td className="p-3 font-mono text-[#8E9299]">subject_verb_agreement_errors</td>
                      <td className="p-3 font-mono font-bold">{stats.errorDistribution['subject-verb-agreement'] || 0}</td>
                    </tr>
                    <tr className={`border-b ${isDark ? 'border-[#2A2D35]' : 'border-slate-100'}`}>
                      <td className="p-3 font-mono text-[#8E9299]">articles_errors</td>
                      <td className="p-3 font-mono font-bold">{stats.errorDistribution['articles'] || 0}</td>
                    </tr>
                    <tr className={`border-b ${isDark ? 'border-[#2A2D35]' : 'border-slate-100'}`}>
                      <td className="p-3 font-mono text-[#8E9299]">common_spelling_errors</td>
                      <td className="p-3 font-mono font-bold">{stats.errorDistribution['common-spelling'] || 0}</td>
                    </tr>
                  </tbody>
                </table>
              )}
            </div>

            {/* Display code query snippet */}
            <div className={`mt-3 p-3 rounded-lg border text-[11px] font-mono ${
              isDark ? 'bg-[#12141A] border-[#2A2D35] text-[#8E9299]' : 'bg-slate-100 border-slate-200 text-slate-600'
            }`}>
              <div className="flex items-center gap-1.5 text-[10px] text-[#8E9299] font-bold uppercase mb-1">
                <FileCode className="w-3.5 h-3.5 text-[#4CAF50]" />
                <span>Simulated Internal DQL Query:</span>
              </div>
              <code className="text-[#4CAF50] select-all font-mono">
                SELECT * FROM {selectedTable === 'custom_dict' ? 'custom_dictionary' : selectedTable};
              </code>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
