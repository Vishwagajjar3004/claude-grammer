export interface AppSettings {
  popupDelay: number; // in ms
  popupSize: 'small' | 'medium' | 'large';
  fontSize: 'small' | 'medium' | 'large';
  autoCorrection: boolean;
  launchOnStartup: boolean;
  theme: 'dark' | 'light' | 'system';
  hotkeyAccept: string;
  hotkeyIgnore: string;
  enabledRules: { [ruleId: string]: boolean };
  engineMode: 'offline' | 'dynamic';
}

export interface GrammarRule {
  id: string;
  name: string;
  category: 'grammar' | 'spelling' | 'punctuation' | 'style' | 'formatting';
  description: string;
  explanation: string;
  enabled: boolean;
}

export interface Suggestion {
  id: string;
  ruleId: string;
  ruleName: string;
  originalText: string;
  suggestedText: string;
  startIndex: number;
  endIndex: number;
  explanation: string;
  type: 'error' | 'warning' | 'info';
  // Additional candidate corrections beyond `suggestedText` (the top pick).
  // Currently only populated by the spelling engine, e.g. for "environment"
  // this might include ["environmental", "environments", "environmentally"].
  alternatives?: string[];
}

export interface SystemLog {
  id: string;
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'perf';
  module: 'GrammarEngine' | 'SpellEngine' | 'Database' | 'Popup' | 'Tray' | 'Settings';
  message: string;
  durationMs?: number;
}

export interface DictionaryItem {
  id: string;
  word: string;
  addedAt: string;
}

export interface HistoryItem {
  id: string;
  timestamp: string;
  original: string;
  corrected: string;
  ruleId: string;
  ruleName: string;
  action: 'accepted' | 'ignored' | 'manual';
}

export interface WritingStats {
  wordsAnalyzed: number;
  correctionsAccepted: number;
  correctionsIgnored: number;
  errorDistribution: { [category: string]: number };
}
